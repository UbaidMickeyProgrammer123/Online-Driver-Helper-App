package com.example.mdhs.CustomAdapters;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.HelperClass.UserHolderHelper;
import com.example.mdhs.Profile.DriverUserRequestProfileToMechanic;
import com.example.mdhs.R;

import java.util.List;

public class MyAdapterRequestCheckByMechanic extends RecyclerView.Adapter<MyAdapterRequestCheckByMechanic.ViewHolder>{


/*
    create adapter for display all near driver request with their
     username and their total distance away from mechanic
     */
//    private String VIEW_HOLDER_TYPE_INTENT_KEY="view_holder_type_intent_key";


    private List<UserHolderHelper>listData;

    public MyAdapterRequestCheckByMechanic(List<UserHolderHelper> listData) {
        this.listData = listData;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.user_item_card_view_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {

        UserHolderHelper ld=listData.get(position);
        holder.txtName.setText(ld.getUserName());
        //get distance up to 2 decimal points
        holder.txtDis.setText(String.format("%.2f", ld.getDistance())+"Km away");
        //set on click listener when detail icon is clicked
        holder.imageView_detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(), DriverUserRequestProfileToMechanic.class);
                intent.putExtra(IntentAttrHelper.USER_NAME_KEY,listData.get(position).getUserName());

                intent.putExtra(IntentAttrHelper.ADDRESS_INTENT_KEY,listData.get(position).getAddress());
                intent.putExtra(IntentAttrHelper.CONTACT_INTENT_KEY,listData.get(position).getContact());
                intent.putExtra(IntentAttrHelper.TOTAL_JOB_INTENT_KEY,listData.get(position).gettJob());

                intent.putExtra(IntentAttrHelper.LATITUDE_INTENT_KEY,listData.get(position).getLatitude().toString());
                intent.putExtra(IntentAttrHelper.LONGITUDE_INTENT_KEY,listData.get(position).getLongitude().toString());
//                intent.putExtra(VIEW_HOLDER_TYPE_INTENT_KEY,"request");
                //get temp holder request status that store in name attribute
                intent.putExtra(IntentAttrHelper.IS_ACTIVE_INTENT_KEY,listData.get(position).getName());


//                intent.putExtra("btn_type","update");
                v.getContext().startActivity(intent);

//                ((MyAdapterView)v.getContext()).finish();
            }
        });



    }

    @Override
    public int getItemCount() {
        return listData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView txtName,txtDis;
        private ImageView imageView_detail;
        public ViewHolder(View itemView) {
            super(itemView);
            txtName=(TextView)itemView.findViewById(R.id.nametxt_feedback_cardview_id);
            txtDis=(TextView)itemView.findViewById(R.id.distance_txt_feedback_cardview_id);
            imageView_detail=itemView.findViewById(R.id.imageView_detail_id);

        }
    }
}
