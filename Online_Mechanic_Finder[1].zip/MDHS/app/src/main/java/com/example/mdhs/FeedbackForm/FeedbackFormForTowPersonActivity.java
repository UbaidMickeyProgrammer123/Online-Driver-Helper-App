package com.example.mdhs.FeedbackForm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mdhs.DataClasses.FeedBack;
import com.example.mdhs.FireBaseDB.FireBaseDAO;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.HelperClass.SharePreferenceAttrHelper;
import com.example.mdhs.MainActivity;
import com.example.mdhs.PaymentDetailActivity;
import com.example.mdhs.R;

public class FeedbackFormForTowPersonActivity extends AppCompatActivity {
    private SharedPreferences sharedPreferences;
    //initialize  firebase dao object
    private FireBaseDAO fireBaseDAO;
    private FireBaseDAO fireBaseDAO1;

    //create intent for set and get intent
//    this intent is for profile and My Adpater only




    //    declare user type string for get intent
    //declare button
    Button button_view_payment_detail_tow,button_submit_form;
    //declare textview

    TextView textView_userName,textView_phoneNo,textView_address,textView_comment;
    //declare for temp holder
    String t_userName, t_address, t_pNo, t_comment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback_form_for_tow_person);

        //initialize textview and button
        textView_userName=findViewById(R.id.textView_Feedback_form_userName_Tow_id);
        textView_address=findViewById(R.id.textView_Feedback_form_Address_Tow_id);
        textView_phoneNo=findViewById(R.id.textView_Feedback_form_contactNo_Tow_id);
        textView_comment=findViewById(R.id.editTextTextPersonName_Feedback_form__feedback_Tow_id);
        button_view_payment_detail_tow =findViewById(R.id.button_Feedback_form_view_pay_detail_Tow_id);
        //no use of back feedback form
        button_submit_form=findViewById(R.id.button_Feedback_form_submit_Tow_id);

        //get intent data from main start screen
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        //create temp holder variables
        t_userName =bundle.getString(IntentAttrHelper.USER_NAME_KEY,"UnKnown");
        t_address =bundle.getString(IntentAttrHelper.ADDRESS_INTENT_KEY,"UnKnown");
        t_pNo =bundle.getString(IntentAttrHelper.CONTACT_INTENT_KEY,"UnKnown");
        //set textview
        textView_userName.setText("Tow UserName\n"+ t_userName);
        textView_address.setText("Tow Address\n"+ t_address);
        textView_phoneNo.setText("Tow Contact No: "+ t_pNo);
//user click on submit form
        button_submit_form.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                t_comment =textView_comment.getText().toString();
                if(t_comment.equals("")){
                    Toast.makeText(getApplicationContext(), "Please enter your feedback", Toast.LENGTH_LONG).show();
                }
                else{

                    sharedPreferences =getSharedPreferences("MyApp",MODE_PRIVATE);

                    String d_userName=sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_DRIVER_KEY,"Nill");

                    fireBaseDAO=new FireBaseDAO();
                    //create Feedback object
                    FeedBack feedBack=new FeedBack(d_userName, t_userName, t_comment);
                    //insert feedback into firebase database in tow person parent
                    fireBaseDAO.insertFeedbackToTowPerson(feedBack);
                    Toast.makeText(getApplicationContext(), "FeedBack Submitted Successfully to "+t_userName+" TowPerson", Toast.LENGTH_SHORT).show();
                    fireBaseDAO1=new FireBaseDAO();
                    fireBaseDAO1.updateTowPersonIsActiveStatus(t_userName,false,getApplicationContext());
                    fireBaseDAO=new FireBaseDAO();
                    //delete all requested after submit feedback by driver
                    fireBaseDAO.deleteRequestToTowPerson(d_userName, t_userName);
                    Intent intent1=new Intent(getApplicationContext(), MainActivity.class);
                    intent1.putExtra(IntentAttrHelper.USER_NAME_KEY,d_userName);
                    intent1.putExtra(IntentAttrHelper.USER_TYPE_KEY,"Driver");
                    startActivity(intent1);
                    finish();

                }
            }
        });
        //user click on back button
        button_view_payment_detail_tow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sharedPreferences =getSharedPreferences("MyApp",MODE_PRIVATE);

                String d_userName=sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_DRIVER_KEY,"Nill");

                Intent intent1=new Intent(getApplicationContext(), PaymentDetailActivity.class);
intent1.putExtra(IntentAttrHelper.PAYMENT_TO_USERNAME_INTENT_KEY,t_userName);
                intent1.putExtra(IntentAttrHelper.PAYMENT_BY_USERNAME_INTENT_KEY,d_userName);
                intent1.putExtra(IntentAttrHelper.USER_TYPE_KEY,"Tow");
                startActivity(intent1);
            }
        });
    }
}