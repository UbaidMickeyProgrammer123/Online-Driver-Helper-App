package com.example.mdhs.DataClasses;

public class Mechanic extends Person {

    Boolean washService;
    Boolean repairService;
    Boolean tyreService;
    int totalJobs;
    Boolean isActive;

//     mechanic.getUserName(),
//                                mechanic.getName(),
//                                mechanic.getContact(),
//                                mechanic.getPass(),
//                                mechanic.getRePass(),
//                                mechanic.getLatitude(),
//                                mechanic.getLongitude(),
//                                mechanic.getAddress(),
//                                mechanic.getWashService(),
//                                mechanic.getRepairService(),
//                                mechanic.getTyreService(),
//                                mechanic.getTotalJobs(),
//                                mechanic.getActive()

    public Mechanic( String userName, String name, String contact,
                    String pass, String rePass, Double latitude, Double longitude,String address, Boolean washService,
                    Boolean repairService, Boolean tyreService, int totalJobs, Boolean active) {
        super(userName, name, contact, pass, rePass, address, latitude, longitude);
        this.washService = washService;
        this.repairService = repairService;
        this.tyreService = tyreService;
        this.totalJobs = totalJobs;
        this.isActive = active;
    }


    public Mechanic(){
        super("Null", "Null", "Null", "Null", "Null","Null",0.00,0.00);
        this.washService = false;
        this.repairService = false;
        this.tyreService = false;
        this.totalJobs = 0;
        this.isActive = false;

    }

    public Mechanic(String email, String name, String contact, String pass, String rePass,
                    Double latitude, Double longitude, String address,
                    Boolean washService, Boolean repairService, Boolean tyreService) {
        super(email, name, contact, pass, rePass,address,latitude,longitude);

        this.washService = washService;
        this.repairService = repairService;
        this.tyreService = tyreService;
    }




    public int getTotalJobs() {
        return totalJobs;
    }

    public void setTotalJobs(int totalJobs) {
        this.totalJobs = totalJobs;
    }

    public Boolean getActive() {
        return isActive;
    }

    public void setActive(Boolean active) {
        isActive = active;
    }


    public Boolean getWashService() {
        return washService;
    }

    public void setWashService(Boolean washService) {
        this.washService = washService;
    }

    public Boolean getRepairService() {
        return repairService;
    }

    public void setRepairService(Boolean repairService) {
        this.repairService = repairService;
    }

    public Boolean getTyreService() {
        return tyreService;
    }

    public void setTyreService(Boolean tyreService) {
        this.tyreService = tyreService;
    }
    public Double getLatitude() {
        return latitude;
    }



    @Override
    public String toString() {
        return "Mechanic{" +
                "washService=" + washService +
                ", repairService=" + repairService +
                ", tyreService=" + tyreService +
                ", UserName='" + UserName + '\'' +
                ", name='" + name + '\'' +
                ", contact='" + contact + '\'' +
                ", pass='" + pass + '\'' +
                ", rePass='" + rePass + '\'' +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                ", address='" + address + '\'' +
                '}';
    }


}
