package com.example.mdhs.FireBaseDB;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import com.example.mdhs.CustomAdapters.MyAdapterViewMechanicForAdmin;
import com.example.mdhs.DataClasses.Driver;
import com.example.mdhs.DataClasses.FeedBack;
import com.example.mdhs.DataClasses.Mechanic;
import com.example.mdhs.DataClasses.Payment;
import com.example.mdhs.DataClasses.ServiceRequest;
import com.example.mdhs.DataClasses.TowPerson;
import com.example.mdhs.HelperClass.AlertDialogueHelper;
import com.example.mdhs.HelperClass.SharePreferenceAttrHelper;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FireBaseDAO  {
    private  DatabaseReference databaseReference;
    private SharedPreferences sharedPreferences;
    private AlertDialogueHelper alertDialogueHelper;


//declare var for check mechanic exit or not after delete admin
    Boolean verification = false;
public FireBaseDAO(){

}
//when mechanic register in firebase database
    public void setUserRegisterData(Mechanic mechanic, String userName, String userType, Context context){
       
        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
            databaseReference.child(userType).child(userName).setValue(mechanic);
        //getting the reference of db node
//set already login key and email key on share preference
        sharedPreferences =context.getSharedPreferences("MyApp",context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
//        Toast.makeText(context.getApplicationContext(), "Mechanic in " +mechanic.getUserName(), Toast.LENGTH_SHORT).show();
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_MECHANIC_KEY,mechanic.getUserName());
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_CONTACT_MECHANIC_KEY,mechanic.getContact());
        editor.commit();

    }
    //when driver register in firebase database

    public void setUserRegisterData(Driver driver, String userName, String userType,Context context){

        //getting the reference of db node

        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        databaseReference.child(userType).child(userName).setValue(driver);
        //set already login key and email key on share preference
        sharedPreferences =context.getSharedPreferences("MyApp",context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
//        Toast.makeText(context, "DAO: userName "+driver.getUserName(), Toast.LENGTH_SHORT).show();
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_DRIVER_KEY,driver.getName());
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_CONTACT_DRIVER_KEY,driver.getContact());

        editor.commit();

    }
    //when tow register in firebase database

    public void setUserRegisterData(TowPerson towPerson, String userName, String userType,Context context){

        //getting the reference of db node

        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        databaseReference.child(userType).child(userName).setValue(towPerson);
        //set already login key and email key on share preference
        sharedPreferences =context.getSharedPreferences("MyApp",context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_TOW_KEY,towPerson.getUserName());
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_CONTACT_TOW_KEY,towPerson.getContact());

        editor.commit();

    }
//update  location detail by any user with user type

    public void updatedCurrentUserLocation(String userName, Double latitude, Double longitude, String address, String userType, Context context){


        if(userType.equals("Mechanic")){
            getExistanceMechanic(userName,latitude,longitude,address,userType,context);


        }
        else if(userType.equals("Driver")){
            //        Toast.makeText(context, sharedPreferences.getString(SHARE_PREFERENCE_USER_NAME_MECHANIC_KEY,"Null"), Toast.LENGTH_SHORT).show();
            databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
            databaseReference.child(userType).child(userName).child("latitude").setValue(latitude);
            databaseReference.child(userType).child(userName).child("longitude").setValue(longitude);
            databaseReference.child(userType).child(userName).child("address").setValue(address);
            //set already login key and email key on share preference
            sharedPreferences =context.getSharedPreferences("MyApp",context.MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedPreferences.edit();
            editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_DRIVER_KEY,userName);
            editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_ADDRESS_DRIVER_KEY,address);
            editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LATITUDE_DRIVER_KEY,String.valueOf(latitude));
            editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LONGITUDE_DRIVER_KEY,String.valueOf(longitude));
            editor.commit();
        }
        else if(userType.equals("Tow")){
            getExistanceTowPerson(userName,latitude,longitude,address,userType,context);
        }

    }
   //set request method when driver request for hire mechanic
    public void setServiceRequestToMechanic(ServiceRequest serviceRequest){
//              Log.e("key1",serviceRequest.toString());
        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        //create db for request to mechanic
        //parent is mechanic and child nodes are driver
        databaseReference.child("RequestToMechanic").child(serviceRequest.getReqToUserName()).
                child(serviceRequest.getReqFromUserName()).
                setValue(serviceRequest);
        //also create db for response from mechanic
        //parent is driver and child nodes are mechanic

        databaseReference.child("ResponseFromMechanic").
                child(serviceRequest.getReqFromUserName()).child(serviceRequest.getReqToUserName()).
                setValue(serviceRequest);
    }

    //set request method when driver request for hire tow person
    public void setServiceRequestToTowPerson(ServiceRequest serviceRequest,Context context){

        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        //create db for request to mechanic
        //parent is tow person and child nodes are driver
        databaseReference.child("RequestToTowPerson").child(serviceRequest.getReqToUserName()).
                child(serviceRequest.getReqFromUserName()).
                setValue(serviceRequest);
        //also create db for response from mechanic
        //parent is driver and child nodes are tow person

        databaseReference.child("ResponseFromTowPerson").
                child(serviceRequest.getReqFromUserName()).child(serviceRequest.getReqToUserName()).
                setValue(serviceRequest);
        Log.e("key1",serviceRequest.toString());
//        Toast.makeText(context, "setServiceRequestToTowPerson", Toast.LENGTH_SHORT).show();
    }
//    create method for update request response from mechanic when mechanic accept or reject request
    public void setMechanicResponseAction(String driverReqUserName,String mechanicResUserName,String request){
        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        //update  db for request to mechanic
        databaseReference.child("RequestToMechanic").
                child(mechanicResUserName).
                child(driverReqUserName).
                child("reqToresponce").
                setValue(request);
//also create db for response from mechanic
        databaseReference.child("ResponseFromMechanic").
                child(driverReqUserName).
                child(mechanicResUserName).
                child("reqToresponce").
                setValue(request);
if (request.equals("Accept")){
    databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
    databaseReference.child("Mechanic").child(mechanicResUserName).child("active").setValue(true);
}
    }

    //    create method for update request response from mechanic when mechanic accept or reject request
    public void setTowPersonResponseAction(String driverReqUserName,String mechanicResUserName,String request,Context context){
        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        //update  db for request to mechanic
        databaseReference.child("RequestToTowPerson").
                child(mechanicResUserName).
                child(driverReqUserName).
                child("reqToresponce").
                setValue(request);
//also create db for response from mechanic
        databaseReference.child("ResponseFromTowPerson").
                child(driverReqUserName).
                child(mechanicResUserName).
                child("reqToresponce").
                setValue(request);
        if (request.equals("Accept")){

//            databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
//            databaseReference.child("Tow").child(mechanicResUserName).child("isActive").setValue(true);


            databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
            databaseReference.child("Tow").child(mechanicResUserName).child("active").setValue(true);

        }
    }

    //update mechanic is Active
    public void updateMechanicIsActiveStatus(String mechanic_UserName,Boolean isActive,Context context){

        if(isActive.equals(true))
        {
            sharedPreferences =context.getSharedPreferences("MyApp",context.MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedPreferences.edit();
            editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_IS_ACTIVE_MECHANIC_NAME,mechanic_UserName);
            editor.commit();
            databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
            databaseReference.child("Mechanic").child(mechanic_UserName).child("active").setValue(isActive);

        }
        if(isActive.equals(false)){
//            Toast.makeText(context, "m_userName is active "+isActive, Toast.LENGTH_SHORT).show();
            databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
            databaseReference.child("Mechanic").child(mechanic_UserName).child("active").setValue(isActive);
        }




    }
    //update mechanic is Active
    public void updateTowPersonIsActiveStatus(String mechanic_UserName,Boolean isActive,Context context){

        if(isActive.equals(true))
        {
            sharedPreferences =context.getSharedPreferences("MyApp",context.MODE_PRIVATE);
            SharedPreferences.Editor editor=sharedPreferences.edit();
            editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_IS_ACTIVE_MECHANIC_NAME,mechanic_UserName);
            editor.commit();
            databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
            databaseReference.child("Tow").child(mechanic_UserName).child("active").setValue(isActive);

        }
        if(isActive.equals(false)){
//            Toast.makeText(context, "m_userName is active "+isActive, Toast.LENGTH_SHORT).show();
            databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
            databaseReference.child("Tow").child(mechanic_UserName).child("active").setValue(isActive);
        }




    }
    //insert feedback method into firebase database
    public void insertFeedback(FeedBack feedBack){
        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        databaseReference.child("Feedback").child("FeedbackTo").
                child(feedBack.getUserNameFeedBackTo()).child(feedBack.getUserNameFeedBackBy())
    .setValue(feedBack);

    }
    //insert feedback method into firebase database
    public void insertFeedbackToTowPerson(FeedBack feedBack){
        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        databaseReference.child("FeedbackTowPerson").child("FeedbackTo").
                child(feedBack.getUserNameFeedBackTo()).child(feedBack.getUserNameFeedBackBy())
                .setValue(feedBack);

    }

    //    delete all request that driver request to mechanic
    public void deleteRequestToMechanic(String driverRequest, String mechanicResponse){

        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        databaseReference.child("ResponseFromMechanic").child(driverRequest).removeValue();
        //    delete driver request that store in mechanic request list
        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        databaseReference.child("RequestToMechanic").child(mechanicResponse).child(driverRequest).removeValue();

        //set isActive false to mechanic
        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        databaseReference.child("Mechanic").child(mechanicResponse).child("active").setValue(false);

    }
    //    delete all request that driver request to mechanic
    public void deleteRequestToTowPerson(String driverRequest, String mechanicResponse){

        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        databaseReference.child("ResponseFromTowPerson").child(driverRequest).removeValue();
        //    delete driver request that store in mechanic request list
        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        databaseReference.child("RequestToTowPerson").child(mechanicResponse).child(driverRequest).removeValue();

        //set isActive false to mechanic
        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        databaseReference.child("Tow").child(mechanicResponse).child("active").setValue(false);

    }

    //delete mechanic by admin when feel bad comments by drivers
    public  void deleteMechanic(String mechanic,Context context){
//        Toast.makeText(context, "AlertDialog", Toast.LENGTH_SHORT).show();
        alertDialogueHelper=new AlertDialogueHelper();
        alertDialogueHelper.alertDelMechanic(mechanic,context);



    }
    //delete mechanic by admin when feel bad comments by drivers
    public  void deleteTowPerson(String towPerson,Context context){
        alertDialogueHelper=new AlertDialogueHelper();
        alertDialogueHelper.alertDelTowPerson(towPerson,context);

    }
    //create method for check mechanic deleted y admin or not
//    if mechanic deleted then remove access of mechanic from Home page and move him to login page
    public Boolean getExistanceMechanic(String userName, Double latitude, Double longitude,
                                        String address, String userType, Context context){
        verification=false;
        final DatabaseReference nm= FirebaseDatabase.getInstance().getReference().child("DB").
                child("Mechanic");
        nm.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    for (DataSnapshot npsnapshot : dataSnapshot.getChildren()){
                        Mechanic l=npsnapshot.getValue(Mechanic.class);

                          if(userName.equals(l.getUserName())){
//check
                              verification=true;

                          }

                    }
//if user already exit in firebase database then execute this if condition
if(verification){

    databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
    databaseReference.child(userType).child(userName).child("latitude").setValue(latitude);
    databaseReference.child(userType).child(userName).child("longitude").setValue(longitude);
    databaseReference.child(userType).child(userName).child("address").setValue(address);
    //set already login key and email key on share preference
    sharedPreferences =context.getSharedPreferences("MyApp",context.MODE_PRIVATE);
    SharedPreferences.Editor editor=sharedPreferences.edit();
    editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_MECHANIC_KEY,userName);
    editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_ADDRESS_MECHANIC_KEY,address);
    editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LATITUDE_MECHANIC_KEY,String.valueOf(latitude));
    editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LONGITUDE_MECHANIC_KEY,String.valueOf(longitude));

    editor.commit();
}
else{


// mechanic again register himself in system after deleted by admin
        sharedPreferences =context.getSharedPreferences("MyApp",context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_MECHANIC_LOGIN_CHECK,"f");
        editor.commit();

}
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    return verification;
    }

    //create method for check mechanic deleted y admin or not
//    if tow person deleted then remove access of tow person from Home page and move him to login page
    public Boolean getExistanceTowPerson(String userName, Double latitude, Double longitude,
                                        String address, String userType, Context context){
        verification=false;
        final DatabaseReference nm= FirebaseDatabase.getInstance().getReference().child("DB").
                child("Tow");
        nm.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    for (DataSnapshot npsnapshot : dataSnapshot.getChildren()){
                        TowPerson l=npsnapshot.getValue(TowPerson.class);

                        if(userName.equals(l.getUserName())){
//check
                            verification=true;

                        }

                    }
//if user already exit in firebase database then execute this if condition
                    if(verification){

                        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
                        databaseReference.child(userType).child(userName).child("latitude").setValue(latitude);
                        databaseReference.child(userType).child(userName).child("longitude").setValue(longitude);
                        databaseReference.child(userType).child(userName).child("address").setValue(address);
                        //set already login key and email key on share preference
                        sharedPreferences =context.getSharedPreferences("MyApp",context.MODE_PRIVATE);
                        SharedPreferences.Editor editor=sharedPreferences.edit();
                        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_TOW_KEY,userName);
                        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_ADDRESS_TOW_KEY,address);
                        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LATITUDE_TOW_KEY,String.valueOf(latitude));
                        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LONGITUDE_TOW_KEY,String.valueOf(longitude));

                        editor.commit();
                    }
                    else{


// mechanic again register himself in system after deleted by admin
                        sharedPreferences =context.getSharedPreferences("MyApp",context.MODE_PRIVATE);
                        SharedPreferences.Editor editor=sharedPreferences.edit();
                        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_TOW_LOGIN_CHECK,"f");
                        editor.commit();

                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        return verification;
    }
    //set share preference  for mechanic and true mechanic login
    public void setMechanic_SP_AfterLogin(Mechanic mechanic,Context context){
        //set already login key and email key on share preference

        sharedPreferences =context.getSharedPreferences("MyApp",context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_MECHANIC_LOGIN_CHECK,"t");
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_MECHANIC_KEY,mechanic.getUserName());
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_CONTACT_MECHANIC_KEY,mechanic.getContact());
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_ADDRESS_MECHANIC_KEY,mechanic.getAddress());
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LATITUDE_MECHANIC_KEY,String.valueOf(mechanic.getLatitude()));
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LONGITUDE_MECHANIC_KEY,String.valueOf(mechanic.getLongitude()));
        editor.putInt(SharePreferenceAttrHelper.SHARE_PREFERENCE_TOTAL_JOB_MECHANIC_KEY,mechanic.getTotalJobs());
        editor.putBoolean(SharePreferenceAttrHelper.SHARE_PREFERENCE_WASH_SERVICE_MECHANIC_KEY,(mechanic.getWashService()));
        editor.putBoolean(SharePreferenceAttrHelper.SHARE_PREFERENCE_REPAIR_SERVICE_MECHANIC_KEY,(mechanic.getRepairService()));
        editor.putBoolean(SharePreferenceAttrHelper.SHARE_PREFERENCE_TYRE_SERVICE_MECHANIC_KEY,(mechanic.getTyreService()));


        editor.commit();
    }


    //set share preference  for driver and true mechanic login
    public void setDriver_SP_AfterLogin(Driver driver,Context context){
        //set already login key and email key on share preference
        sharedPreferences =context.getSharedPreferences("MyApp",context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_DRIVER_LOGIN_CHECK,"t");
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_DRIVER_KEY,driver.getUserName());
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_CONTACT_DRIVER_KEY,driver.getContact());
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_ADDRESS_DRIVER_KEY,driver.getAddress());
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LATITUDE_DRIVER_KEY,String.valueOf(driver.getLatitude()));
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LONGITUDE_DRIVER_KEY,String.valueOf(driver.getLongitude()));
        editor.commit();
    }

    //set share preference  for driver and true mechanic login
    public void setTow_SP_AfterLogin(TowPerson towPerson,Context context){
        //set already login key and email key on share preference
        sharedPreferences =context.getSharedPreferences("MyApp",context.MODE_PRIVATE);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_TOW_LOGIN_CHECK,"t");
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_TOW_KEY,towPerson.getUserName());
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_CONTACT_TOW_KEY,towPerson.getContact());
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_ADDRESS_TOW_KEY,towPerson.getAddress());
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LATITUDE_TOW_KEY,String.valueOf(towPerson.getLatitude()));
        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LONGITUDE_TOW_KEY,String.valueOf(towPerson.getLongitude()));
        editor.putInt(SharePreferenceAttrHelper.SHARE_PREFERENCE_TOTAL_JOB_TOW_KEY,towPerson.getTotalJobs());

        editor.commit();
    }
    public void updateTotalJobTowPerson(String towUserName,Context context){
        //update totalJob
        int updateJob;
//            increment by 1 when tow peron accept request
        sharedPreferences =context.getSharedPreferences("MyApp",context.MODE_PRIVATE);
        updateJob=sharedPreferences.getInt(SharePreferenceAttrHelper.SHARE_PREFERENCE_TOTAL_JOB_TOW_KEY,0)+1;

        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        databaseReference.child("Tow").child(towUserName).child("totalJobs").setValue(updateJob);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putInt(SharePreferenceAttrHelper.SHARE_PREFERENCE_TOTAL_JOB_TOW_KEY,updateJob);
        editor.commit();

    }
    public void updateTotalJobMechanic(String mechanicUserName,Context context){
        //update totalJob
        int updateJob;
//            increment by 1 when tow peron accept request
        sharedPreferences =context.getSharedPreferences("MyApp",context.MODE_PRIVATE);
        updateJob=sharedPreferences.getInt(SharePreferenceAttrHelper.SHARE_PREFERENCE_TOTAL_JOB_MECHANIC_KEY,0)+1;

        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        databaseReference.child("Mechanic").child(mechanicUserName).child("totalJobs").setValue(updateJob);
        SharedPreferences.Editor editor=sharedPreferences.edit();
        editor.putInt(SharePreferenceAttrHelper.SHARE_PREFERENCE_TOTAL_JOB_MECHANIC_KEY,updateJob);
        editor.commit();

    }

    //insert payment detail in db
    public void insertPaymentDetailMechanic(Payment payment){
        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        databaseReference.child("PaymentDetailMechanic").child(payment.getUserPayTo()).child(payment.getUserPayBy()).setValue(payment);
    }
    //insert payment detail in db
    public void insertPaymentDetailTow(Payment payment){
        databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
        databaseReference.child("PaymentDetailTow").child(payment.getUserPayTo()).child(payment.getUserPayBy()).setValue(payment);
    }
}
