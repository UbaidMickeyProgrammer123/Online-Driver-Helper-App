package com.example.mdhs.DataClasses;

public class ServiceRequest {

    String reqFromUserName;

    @Override
    public String toString() {
        return "ServiceRequest{" +
                "reqFromUserName='" + reqFromUserName + '\'' +
                ", reqFromContact='" + reqFromContact + '\'' +
                ", reqFromAddress='" + reqFromAddress + '\'' +
                ", reqFromLatitude='" + reqFromLatitude + '\'' +
                ", reqFromLogitude='" + reqFromLogitude + '\'' +
                ", reqToUserName='" + reqToUserName + '\'' +
                ", reqToContact='" + reqToContact + '\'' +
                ", reqToAddress='" + reqToAddress + '\'' +
                ", reqToLatitude='" + reqToLatitude + '\'' +
                ", reqToLogitude='" + reqToLogitude + '\'' +
                ", reqToresponce='" + reqToresponce + '\'' +
                '}';
    }

    String reqFromContact;
    String reqFromAddress;
    String reqFromLatitude;
    String reqFromLogitude;
    String reqToUserName;



    String reqToContact;
    String reqToAddress;
    String reqToLatitude;
    String reqToLogitude;
    String reqToresponce;
    public ServiceRequest() {
        this.reqFromUserName = "Nill";
        this.reqFromContact = "Nill";
        this.reqFromAddress = "Nill";
        this.reqFromLatitude = "Nill";
        this.reqFromLogitude = "Nill";
        this.reqToUserName = "Nill";
        this.reqToContact = "Nill";
        this.reqToAddress = "Nill";
        this.reqToLatitude = "Nill";
        this.reqToLogitude = "Nill";
        this.reqToresponce = "Nill";
    }

    public ServiceRequest(String reqFromUserName, String reqFromContact,
                          String reqFromAddress, String reqFromLatitude, String reqFromLogitude,
                          String reqToUserName,
                          String reqToContact, String reqToAddress, String reqToLatitude,
                          String reqToLogitude, String reqToresponce) {

        this.reqFromUserName = reqFromUserName;
        this.reqFromContact = reqFromContact;
        this.reqFromAddress = reqFromAddress;
        this.reqFromLatitude = reqFromLatitude;
        this.reqFromLogitude = reqFromLogitude;
        this.reqToUserName = reqToUserName;
        this.reqToContact = reqToContact;
        this.reqToAddress = reqToAddress;
        this.reqToLatitude = reqToLatitude;
        this.reqToLogitude = reqToLogitude;
        this.reqToresponce = reqToresponce;
    }



    public String getReqFromUserName() {
        return reqFromUserName;
    }

    public void setReqFromUserName(String reqFromUserName) {
        this.reqFromUserName = reqFromUserName;
    }

    public String getReqFromContact() {
        return reqFromContact;
    }

    public void setReqFromContact(String reqFromContact) {
        this.reqFromContact = reqFromContact;
    }

    public String getReqFromAddress() {
        return reqFromAddress;
    }

    public void setReqFromAddress(String reqFromAddress) {
        this.reqFromAddress = reqFromAddress;
    }

    public String getReqFromLatitude() {
        return reqFromLatitude;
    }

    public void setReqFromLatitude(String reqFromLatitude) {
        this.reqFromLatitude = reqFromLatitude;
    }

    public String getReqFromLogitude() {
        return reqFromLogitude;
    }

    public void setReqFromLogitude(String reqFromLogitude) {
        this.reqFromLogitude = reqFromLogitude;
    }

    public String getReqToUserName() {
        return reqToUserName;
    }

    public void setReqToUserName(String reqToUserName) {
        this.reqToUserName = reqToUserName;
    }

    public String getReqToContact() {
        return reqToContact;
    }

    public void setReqToContact(String reqToContact) {
        this.reqToContact = reqToContact;
    }

    public String getReqToAddress() {
        return reqToAddress;
    }

    public void setReqToAddress(String reqToAddress) {
        this.reqToAddress = reqToAddress;
    }

    public String getReqToLatitude() {
        return reqToLatitude;
    }

    public void setReqToLatitude(String reqToLatitude) {
        this.reqToLatitude = reqToLatitude;
    }

    public String getReqToLogitude() {
        return reqToLogitude;
    }

    public void setReqToLogitude(String reqToLogitude) {
        this.reqToLogitude = reqToLogitude;
    }

    public String getReqToresponce() {
        return reqToresponce;
    }

    public void setReqToresponce(String reqToresponce) {
        this.reqToresponce = reqToresponce;
    }







}
