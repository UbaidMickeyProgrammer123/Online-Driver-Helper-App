package com.example.mdhs.RecyclerView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.example.mdhs.CustomAdapters.MyAdapterViewFeedback;
import com.example.mdhs.DataClasses.FeedBack;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class FeebackTowPersonRecyclerView extends AppCompatActivity {
    //    Recycler view for view feedback of particular driver
//    declare variables
    String towPerson;
    RecyclerView recyclerView_feedback;
    private List<FeedBack> feedBackList;
    MyAdapterViewFeedback myAdapterViewFeedback;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feeback_tow_person_recycler_view);

        Intent intent=getIntent();
        Bundle bundle=intent.getExtras();
        //bind variables
        towPerson =bundle.getString(IntentAttrHelper.USER_NAME_KEY);
        recyclerView_feedback=findViewById(R.id.recyclerView_feedback_Tow_id);
        recyclerView_feedback.setHasFixedSize(true);
        recyclerView_feedback.setLayoutManager(new LinearLayoutManager(this));
        feedBackList=new ArrayList<>();
        //view all feedback related to particular towPerson name
        getAllFeedback();
    }
    private void getAllFeedback() {
        //view all feedback related to particular towPerson name
//
        final DatabaseReference nm= FirebaseDatabase.getInstance().getReference().child("DB").
                child("FeedbackTowPerson").child("FeedbackTo").child(towPerson);
        nm.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    for (DataSnapshot npsnapshot : dataSnapshot.getChildren()){
                        FeedBack l=npsnapshot.getValue(FeedBack.class);
                        //add all feedback into arraylist
                        feedBackList.add(l)   ;


                    }
//array list pass in adapter
                    myAdapterViewFeedback =new MyAdapterViewFeedback(feedBackList);
                    recyclerView_feedback.setAdapter(myAdapterViewFeedback);


                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}