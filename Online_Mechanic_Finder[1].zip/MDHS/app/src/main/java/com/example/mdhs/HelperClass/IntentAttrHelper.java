package com.example.mdhs.HelperClass;

public class IntentAttrHelper {
    //create and declare var for Intent
    public static String USER_TYPE_KEY = "USER_TYPE_KEY";
    public static String USER_NAME_KEY = "USER_NAME_KEY";
    public static String ADDRESS_INTENT_KEY="address_intent_key";
    public static String CONTACT_INTENT_KEY="contact_intent_key";
    public static String TOTAL_JOB_INTENT_KEY="total_job_intent_key";
    public static String IS_ACTIVE_INTENT_KEY="is_active_intent_key";
    public static String LATITUDE_INTENT_KEY="latitude_intent_key";
    public static String LONGITUDE_INTENT_KEY="longitude_intent_key";
    public static String WASH_SERVICE_INTENT_KEY="WASH_SERVICE_INTENT_KEY";
    public static String REPAIR_SERVICE_INTENT_KEY="REPAIR_SERVICE_INTENT_KEY";
    public static String TYRE_SERVICE_INTENT_KEY="TYRE_SERVICE_INTENT_KEY";


    public static String PAYMENT_BY_USERNAME_INTENT_KEY="PAYMENT_BY_USERNAME_INTENT_KEY";
    public static String PAYMENT_TO_USERNAME_INTENT_KEY="PAYMENT_TO_USERNAME_INTENT_KEY";




}
