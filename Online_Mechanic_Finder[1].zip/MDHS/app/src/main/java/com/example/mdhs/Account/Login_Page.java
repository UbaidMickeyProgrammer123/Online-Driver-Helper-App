package com.example.mdhs.Account;



import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mdhs.AdminChoiceActivity;
import com.example.mdhs.DataClasses.Driver;
import com.example.mdhs.DataClasses.Mechanic;
import com.example.mdhs.DataClasses.TowPerson;
import com.example.mdhs.FireBaseDB.FireBaseDAO;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.HelperClass.SharePreferenceAttrHelper;
import com.example.mdhs.MainActivity;
import com.example.mdhs.MapGoogleActivity.MapsActivity;
import com.example.mdhs.R;
import com.example.mdhs.RecyclerView.ViewUserForModifyByAdminRecyclerView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Login_Page extends AppCompatActivity {
//declare for user if exit in db then save all share preference related to that user
Boolean checkUserCredential;
//declare firebase dao object
FireBaseDAO fireBaseDAO;

    //    declare user type string for get intent
    private String userType = "";
    private String userName = "";
    //declare  on share preference object
    private SharedPreferences sharedPreferences;


//    declare and initially initialize false for verification process

  private   Boolean checkEmail = false;
   private Boolean checkPass=false;
    // declare firebase database

    DatabaseReference databaseReference;
    //declare variables
    ProgressBar progressBar;
    Button button_signup1, button_back, button_login;
    TextView textView_new_here;
    EditText editText_userName_id, editText_password_id;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);
        //initialize buttons
        button_signup1 = findViewById(R.id.button_signup1);
        button_back = findViewById(R.id.back_button_map_id);
        button_login = findViewById(R.id.button_login);
        //initialize edittext view email and pass
        editText_userName_id = findViewById(R.id.etv_UserName_id);
        editText_password_id = findViewById(R.id.etv_password);
        // //initialization variables text view
        textView_new_here = findViewById(R.id.textView_new_here_id);
//initialize progress bar
        progressBar=findViewById(R.id.progressBar_login_id);
//get intent data from main start screen
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
//         initialize userType String to store intent USER_TYPE_KEY value
        userType = bundle.getString(IntentAttrHelper.USER_TYPE_KEY, "NILL");
//        Toast.makeText(getApplicationContext(), userType, Toast.LENGTH_SHORT).show();


//check user if it is admin then hide register button

        if (userType.equals("Admin")) {
            button_signup1.setVisibility(View.GONE);
            textView_new_here.setVisibility(View.GONE);
        }
        /*::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
        /*::                                                                          */
        /*::  There are three button in login screen if user have existing            */
        /*::  account then he/she login directly in system                            */
        /*::  if user cannot have account then he must register himself in system    :*/
        /*::                                                                         :*/
        /*::  in all user login access first system get and check user credential    :*/
        /*::    and  if user exit in DB firebase then get all needed data and        :*/
        /*::    set share preference local store in app for particular user          :*/
        /*::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/

//click register button
        button_signup1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), SignUpActivity.class);
                intent.putExtra(IntentAttrHelper.USER_TYPE_KEY, userType);
                startActivity(intent);
                finish();
            }
        });

        //click login button
        button_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //set progress bar visible when click on signUp button
                progressBar.setVisibility(View.VISIBLE);
                checkEmail = false;
                checkPass=false;

//                //get record function
//                 if(userType.equals("Admin")){
//
//                 }
//                 else if(!userType.equals("Admin")){
                     checkLoginCredentialsUserRecord();
                progressBar.setVisibility(View.GONE);

//                 }

               


            }
        });
//click back button
        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();

            }
        });
    }
//method for check credential for user
    private void checkLoginCredentialsUserRecord() {
        checkUserCredential=false;
        checkPass=false;
        checkPass=false;
        String user, pass;
        user = editText_userName_id.getText().toString();
        pass = editText_password_id.getText().toString();
//if field is empty then show error message
        if (user.equals("")) {
            editText_userName_id.setError("Please enter email");
        } else if (pass.equals("")) {
            editText_password_id.setError("Please enter pass");
        } else {


//                Toast.makeText(getApplicationContext(), " get  data " + arrayList, Toast.LENGTH_SHORT).show();

//declare and initialize array for store user from firebase data base for check user existence
            ArrayList<Mechanic> arrayListMechanic = new ArrayList<Mechanic>();
            ArrayList<Driver> driverArrayList=new ArrayList<Driver>();
            ArrayList<TowPerson> towPersonArrayList=new ArrayList<TowPerson>();
            //if user is Mechanic
            if(userType.equals("Mechanic")){
                //getting the reference of db node

                databaseReference = FirebaseDatabase.getInstance().getReference().child("DB").child(userType);
            ValueEventListener getData = databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    Iterable<DataSnapshot> children = snapshot.getChildren();
//get all data form DB
                    for (DataSnapshot child : children) {

                        Mechanic mechanic = child.getValue(Mechanic.class);

                        arrayListMechanic.add(new Mechanic(
                                mechanic.getUserName(),
                                mechanic.getName(),
                                mechanic.getContact(),
                                mechanic.getPass(),
                                mechanic.getRePass(),
                                mechanic.getLatitude(),
                                mechanic.getLongitude(),
                                mechanic.getAddress(),
                                mechanic.getWashService(),
                                mechanic.getRepairService(),
                                mechanic.getTyreService(),
                                mechanic.getTotalJobs(),
                                mechanic.getActive()
                        ));
//                        Toast.makeText(getApplicationContext(), mechanic.getName(), Toast.LENGTH_SHORT).show();

                    }
                    checkVerificatiomMethodMechanic(arrayListMechanic);
                    //set progress bar invisible when after checkVerificatiomMethod  method is complete

                    //if both values true then move on next Map activity
                    if(checkEmail==true&&checkPass==true){

                        //set already login key and email key on share preference
                        sharedPreferences =getSharedPreferences("MyApp",MODE_PRIVATE);
                        SharedPreferences.Editor editor=sharedPreferences.edit();

                        editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_MECHANIC_KEY,userName);
                         editor.commit();
                        Intent intent=new Intent(getApplicationContext(), MapsActivity.class);
                        intent.putExtra(IntentAttrHelper.USER_TYPE_KEY,userType);
                        intent.putExtra(IntentAttrHelper.USER_NAME_KEY,userName);


                        startActivity(intent);
                        finish();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
            }
            //if user is Driver
            else if(userType.equals("Driver")){
                //getting the reference of db node
                databaseReference = FirebaseDatabase.getInstance().getReference().child("DB").child(userType);
                ValueEventListener getData = databaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Iterable<DataSnapshot> children = snapshot.getChildren();

                        for (DataSnapshot child : children) {

                            Driver driver = child.getValue(Driver.class);
                            driverArrayList.add(new Driver(
                                    driver.getUserName(),
                                    driver.getName(),
                                    driver.getContact(),
                                    driver.getPass(),
                                    driver.getRePass(),
                                    driver.getAddress(),
                                    driver.getLatitude(),
                                    driver.getLongitude()
                            ));


                        }
                        checkVerificatiomMethodDriver(driverArrayList);
                        //set progress bar invisible when after checkVerificatiomMethod  method is complete
//                        progressBar.setVisibility(View.INVISIBLE);

                        //if both values true then move on next activity
                        if(checkEmail==true&&checkPass==true){

                            //set already login key and email key on share preference
                            sharedPreferences =getSharedPreferences("MyApp",MODE_PRIVATE);
                            SharedPreferences.Editor editor=sharedPreferences.edit();

                            editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_DRIVER_KEY,userName);
                            editor.commit();
                            Intent intent=new Intent(getApplicationContext(),MapsActivity.class);
                            intent.putExtra(IntentAttrHelper.USER_TYPE_KEY,userType);
                            intent.putExtra(IntentAttrHelper.USER_NAME_KEY,userName);
                            startActivity(intent);
                            finish();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
            //if user is Tow
            else if(userType.equals("Tow")){
                //getting the reference of db node
                databaseReference = FirebaseDatabase.getInstance().getReference().child("DB").child(userType);
                ValueEventListener getData = databaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Iterable<DataSnapshot> children = snapshot.getChildren();
//
                        for (DataSnapshot child : children) {

                            TowPerson towPerson = child.getValue(TowPerson.class);
                            towPersonArrayList.add(new TowPerson(
                                    towPerson.getUserName(),
                                    towPerson.getName(),
                                    towPerson.getContact(),
                                    towPerson.getPass(),
                                    towPerson.getRePass(),
                                    towPerson.getAddress(),
                                    towPerson.getLatitude(),
                                    towPerson.getLongitude(),
                                    towPerson.getTotalJobs(),
                                    towPerson.getActive()


                            ));
//                        Toast.makeText(getApplicationContext(), mechanic.getName(), Toast.LENGTH_SHORT).show();

                        }
                        checkVerificatiomMethodTowPerson(towPersonArrayList);
                        //set progress bar invisible when after checkVerificatiomMethod  method is complete
                        progressBar.setVisibility(View.INVISIBLE);

                        //if both values true then move on next activity
                        if(checkEmail==true&&checkPass==true){

                            //set already login key and email key on share preference
                            sharedPreferences =getSharedPreferences("MyApp",MODE_PRIVATE);
                            SharedPreferences.Editor editor=sharedPreferences.edit();

                            editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_TOW_KEY,userName);
                            editor.commit();
                            Intent intent=new Intent(getApplicationContext(),MapsActivity.class);
                            intent.putExtra(IntentAttrHelper.USER_TYPE_KEY,userType);
                            intent.putExtra(IntentAttrHelper.USER_NAME_KEY,userName);
                            startActivity(intent);
                            finish();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
            //if user is admin
            else if(userType.equals("Admin")){
                if(editText_userName_id.getText().toString().equals("admin")&& editText_password_id.getText().toString().equals("123")){
                    sharedPreferences =getSharedPreferences("MyApp",MODE_PRIVATE);
                    SharedPreferences.Editor editor=sharedPreferences.edit();
                    editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_ADMIN_LOGIN_CHECK,"t");
                    editor.commit();
                    Intent intent1=new Intent(getApplicationContext(), AdminChoiceActivity.class);

                    startActivity(intent1);
                    finish();
                }
            }


        }
//

    }
//create  method for checkVerificatiomMethodTowPerson
    private void checkVerificatiomMethodTowPerson(ArrayList<TowPerson> arrayList1) {
        for (int i = 0; i < arrayList1.size(); i++) {
//match current and db values if match then move on map activity
            if(editText_userName_id.getText().toString().equals(arrayList1.get(i).getUserName())
                    &&editText_password_id.getText().toString().equals(arrayList1.get(i).getPass()))
            {
                fireBaseDAO=new FireBaseDAO();
                //call setTow_SP_AfterLogin method and pass tow object
                fireBaseDAO.setTow_SP_AfterLogin(arrayList1.get(i),getApplicationContext());
                //take userEmail value from field
                userName= editText_userName_id.getText().toString();
                editText_userName_id.setText("");
                editText_password_id.setText("");


                checkEmail=true;
                checkPass=true;
                return;

            }
//if userName cannot exits in db
            else if(!editText_userName_id.getText().toString().equals(arrayList1.get(i).getUserName()))
            {
                editText_userName_id.setError("User Name is wrong");
                checkEmail=false;
            }
            //if password cannot exits in db

            else if(!editText_password_id.getText().toString().equals(arrayList1.get(i).getPass())){
                editText_password_id.setError("Password is wrong");
                checkPass=false;

            }



        }
    }

    //create  method for checkVerificatiomMethodMechanic
    //    get mechanic record
    public void checkVerificatiomMethodMechanic(ArrayList<Mechanic> arrayList1) {

        for (int i = 0; i < arrayList1.size(); i++) {
//match current and db values if match then move on map activity
            if(editText_userName_id.getText().toString().equals(arrayList1.get(i).getUserName())
                    &&editText_password_id.getText().toString().equals(arrayList1.get(i).getPass()))
            {
                //call setMechanic_SP_AfterLogin method and pass tow object
//                Toast.makeText(getApplicationContext(), "login admin get detail"+arrayList1.get(i).toString(), Toast.LENGTH_SHORT).show();
               fireBaseDAO=new FireBaseDAO();
                fireBaseDAO.setMechanic_SP_AfterLogin(arrayList1.get(i),getApplicationContext());
                //take userEmail value from field
                userName= editText_userName_id.getText().toString();
                editText_userName_id.setText("");
                editText_password_id.setText("");

                checkEmail=true;
                checkPass=true;
                return;

            }

          else if(!editText_userName_id.getText().toString().equals(arrayList1.get(i).getUserName()))
            {
//                Toast.makeText(getApplicationContext(), "editText_userName_id is wrong", Toast.LENGTH_SHORT).show();
                editText_userName_id.setError("User Name is wrong");
                checkEmail=false;
            }
           else if(!editText_password_id.getText().toString().equals(arrayList1.get(i).getPass())){
               editText_password_id.setError("Password is wrong");
               checkPass=false;

            }



        }


    }
    //create  method for checkVerificatiomMethodDriver
    //    get mechanic record
    public void checkVerificatiomMethodDriver(ArrayList<Driver> arrayList1) {
//        Toast.makeText(getApplicationContext(), "driver loop ", Toast.LENGTH_SHORT).show();

        for (int i = 0; i < arrayList1.size(); i++) {
//match current and db values if match then move on map activity
            if(editText_userName_id.getText().toString().equals(arrayList1.get(i).getUserName())
                    &&editText_password_id.getText().toString().equals(arrayList1.get(i).getPass()))
            {
                fireBaseDAO=new FireBaseDAO();
                //call setDriver_SP_AfterLogin method and pass tow object
                fireBaseDAO.setDriver_SP_AfterLogin(arrayList1.get(i),getApplicationContext());
                //take userEmail value from field
                userName= editText_userName_id.getText().toString();
                editText_userName_id.setText("");
                editText_password_id.setText("");

                checkEmail=true;
                checkPass=true;
                return;

            }

            else if(!editText_userName_id.getText().toString().equals(arrayList1.get(i).getUserName()))
            {
                editText_userName_id.setError("User Name is wrong");
                checkEmail=false;
            }
            else if(!editText_password_id.getText().toString().equals(arrayList1.get(i).getPass())){
                editText_password_id.setError("Password is wrong");
                checkPass=false;

            }


        }


    }
}
