package com.example.mdhs.DataClasses;

public class TowPerson extends Person{
    private int totalJobs;
    private  Boolean isActive;

public TowPerson(){

        super("Null", "Null", "Null", "Null", "Null","Null",0.00,0.00);
    this.totalJobs = 0;
    this.isActive = false;

}
    public TowPerson(String UserName, String name, String contact, String pass, String rePass,
                     String address, Double latitude, Double longitude, int totalJobs, Boolean isActive) {
        super(UserName, name, contact, pass, rePass, address, latitude, longitude);
        this.totalJobs = totalJobs;
        this.isActive = isActive;
    }


    public TowPerson(String UserName, String name, String contact, String pass, String rePass, String address, Double latitude, Double longitude) {
        super(UserName, name, contact, pass, rePass, address, latitude, longitude);
    }

    public int getTotalJobs() {
        return totalJobs;
    }

    public void setTotalJobs(int totalJobs) {
        this.totalJobs = totalJobs;
    }

    public Boolean getActive() {
        return isActive;
    }

    public void setActive(Boolean active) {
        isActive = active;
    }
}
