package com.example.mdhs.HelperClass;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

import com.example.mdhs.RecyclerView.ViewUserForModifyByAdminRecyclerView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AlertDialogueHelper  {
    private DatabaseReference databaseReference;

    public AlertDialogueHelper(){

   }
    public void alertDelMechanic(String mechanic ,Context context){
        // Create the object of
        // AlertDialog Builder class
        AlertDialog.Builder builder
                = new AlertDialog
                .Builder(context);

        // Set the message show for the Alert time
        builder.setMessage("You will not be able to recover this Mechanic ?");


        // Set Alert Title
        builder.setTitle("Are You Sure!");

        // Set Cancelable false
        // for when the user clicks on the outside
        // the Dialog Box then it will remain show
        builder.setCancelable(false);

        // Set the positive button with yes name
        // OnClickListener method is use of
        // DialogInterface interface.

        builder
                .setPositiveButton(
                        "Delete AnyWay",
                        new DialogInterface
                                .OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which)
                            {

                                // When the user click yes button
                                // then app will close
//                                 ((ViewUserForModifyByAdminRecyclerView)v.getContext()).finish();
                                  databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
                                  databaseReference.child("Mechanic").child(mechanic).removeValue();
                                ((ViewUserForModifyByAdminRecyclerView)context).finish();
                            }
                        });

        // Set the Negative button with No name
        // OnClickListener method is use
        // of DialogInterface interface.
        builder
                .setNegativeButton(
                        "Cancel",
                        new DialogInterface
                                .OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which)
                            {

                                // If user click no
                                // then dialog box is canceled.
                                dialog.cancel();
                            }
                        });

        // Create the Alert dialog
        AlertDialog alertDialog = builder.create();

        // Show the Alert Dialog box
        alertDialog.show();
    }
    public void alertDelTowPerson(String towPerson ,Context context){
        // Create the object of
        // AlertDialog Builder class
        AlertDialog.Builder builder
                = new AlertDialog
                .Builder(context);

        // Set the message show for the Alert time
        builder.setMessage("You will not be able to recover this TowPerson ?");

        // Set Alert Title
        builder.setTitle("Are You Sure!");

        // Set Cancelable false
        // for when the user clicks on the outside
        // the Dialog Box then it will remain show
        builder.setCancelable(false);

        // Set the positive button with yes name
        // OnClickListener method is use of
        // DialogInterface interface.

        builder
                .setPositiveButton(
                        "Delete AnyWay",
                        new DialogInterface
                                .OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which)
                            {

                                // When the user click yes button
                                // then app will close
//                                 ((ViewUserForModifyByAdminRecyclerView)v.getContext()).finish();
                                databaseReference = FirebaseDatabase.getInstance().getReference().child("DB");
                                databaseReference.child("Tow").child(towPerson).removeValue();
                                ((ViewUserForModifyByAdminRecyclerView)context).finish();
                            }
                        });

        // Set the Negative button with No name
        // OnClickListener method is use
        // of DialogInterface interface.
        builder
                .setNegativeButton(
                        "Cancel",
                        new DialogInterface
                                .OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which)
                            {

                                // If user click no
                                // then dialog box is canceled.
                                dialog.cancel();
                            }
                        });

        // Create the Alert dialog
        AlertDialog alertDialog = builder.create();

        // Show the Alert Dialog box
        alertDialog.show();
    }

}
