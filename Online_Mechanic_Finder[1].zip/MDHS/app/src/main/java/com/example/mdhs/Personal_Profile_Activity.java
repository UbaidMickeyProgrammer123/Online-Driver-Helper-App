package com.example.mdhs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.mdhs.DataClasses.ServiceRequest;
import com.example.mdhs.FireBaseDB.FireBaseDAO;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.HelperClass.SharePreferenceAttrHelper;
import com.example.mdhs.MapGoogleActivity.MapsActivity;

public class Personal_Profile_Activity extends AppCompatActivity {
    //declare SharedPreferences  object
    private SharedPreferences sharedPreferences;
    //declare  firebase dao object
    FireBaseDAO fireBaseDAO;
    //declare Service Request object
    private ServiceRequest serviceRequest;
    //declare button
    Button button_back_profile;
    //declare textview
    TextView textView_userName,textView_phoneNo,textView_address,textView_total_job,textView_isActive,textView_latitude
            ,textView_logitude;
    //declare for temp holder
    String userTypeIntent,userNameIntent;
    String userName, user_address, user_pNo,  user_lat, user_lon;
    int user_tJob;
    Boolean isActive;
    Boolean washService,repairService,tyreService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_profile);
        //initialize textview and button
        textView_userName=findViewById(R.id.textView_personal_profile_userName_id);
        textView_address=findViewById(R.id.textView_personal_profile_Address_id);
        textView_phoneNo=findViewById(R.id.textView_personal_profile_contactNo_id);
        textView_total_job=findViewById(R.id.textView_personal_profile_total_job_id);
        textView_isActive=findViewById(R.id.textView_personal_profile_isActive_id);
        textView_latitude=findViewById(R.id.textView_personal_profile_latitude_id);
        textView_logitude=findViewById(R.id.textView_personal_profile_longitude_id);
        button_back_profile=findViewById(R.id.button_personal_profile_back_id);

        //get intent data from main start screen
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        //create temp holder variables
        userTypeIntent =bundle.getString(IntentAttrHelper.USER_TYPE_KEY,"UnKnown");
        userNameIntent =bundle.getString(IntentAttrHelper.USER_NAME_KEY,"UnKnown");
        if (userTypeIntent.equals("Driver")){
            sharedPreferences =getSharedPreferences("MyApp",MODE_PRIVATE);
            userName=sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_DRIVER_KEY,"Null");
            user_address =sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_ADDRESS_DRIVER_KEY,"Null");
            user_pNo =sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_CONTACT_DRIVER_KEY,"Null");
            user_lat =sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LATITUDE_DRIVER_KEY,"Null");
            user_lon =sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LONGITUDE_DRIVER_KEY,"Null");
            textView_userName.setText("User Name: "+userName);
            textView_address.setText("Address: "+user_address);
            textView_phoneNo.setText("Contact No:"+user_pNo);
            textView_latitude.setText("Latitude: "+user_lat);
            textView_logitude.setText("Longitude: "+user_lon);
            textView_total_job.setVisibility(View.GONE);
            textView_isActive.setVisibility(View.GONE);

        }
        else if (userTypeIntent.equals("Mechanic")){
            sharedPreferences =getSharedPreferences("MyApp",MODE_PRIVATE);
            userName=sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_MECHANIC_KEY,"Null");
            user_address =sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_ADDRESS_MECHANIC_KEY,"Null");
            user_pNo =sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_CONTACT_MECHANIC_KEY,"Null");
            user_lat =sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LATITUDE_MECHANIC_KEY,"Null");
            user_lon =sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LONGITUDE_MECHANIC_KEY,"Null");
            washService=sharedPreferences.getBoolean(SharePreferenceAttrHelper.SHARE_PREFERENCE_WASH_SERVICE_MECHANIC_KEY,false);
            repairService=sharedPreferences.getBoolean(SharePreferenceAttrHelper.SHARE_PREFERENCE_REPAIR_SERVICE_MECHANIC_KEY,false);
            tyreService=sharedPreferences.getBoolean(SharePreferenceAttrHelper.SHARE_PREFERENCE_TYRE_SERVICE_MECHANIC_KEY,false);
            user_tJob=sharedPreferences.getInt(SharePreferenceAttrHelper.SHARE_PREFERENCE_TOTAL_JOB_MECHANIC_KEY,0);
String ser="";
            textView_userName.setText("User Name: "+userName);
            textView_address.setText("Address: "+user_address);
            textView_phoneNo.setText("Contact No:"+user_pNo);
            textView_latitude.setText("Latitude: "+user_lat);
            textView_logitude.setText("Longitude: "+user_lon);
            textView_total_job.setVisibility(View.VISIBLE);
            if(washService.equals(true)){
                ser=ser+"wash, ";
            }
            if(repairService.equals(true)){
                ser=ser+"repair, ";
            }
            if(tyreService.equals(true)){
                ser=ser+"tyre, ";
            }
            textView_isActive.setVisibility(View.GONE);
            textView_total_job.setText("TotalJob: "+String.valueOf(user_tJob)+"\n\nServices : "+ser);
        }
        else if (userTypeIntent.equals("Tow")){
            sharedPreferences =getSharedPreferences("MyApp",MODE_PRIVATE);
            userName=sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_TOW_KEY,"Null");
            user_address =sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_ADDRESS_TOW_KEY,"Null");
            user_pNo =sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_CONTACT_TOW_KEY,"Null");
            user_lat =sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LATITUDE_TOW_KEY,"Null");
            user_lon =sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LONGITUDE_TOW_KEY,"Null");
            textView_userName.setText("User Name: "+userName);
            textView_address.setText("Address: "+user_address);
            textView_phoneNo.setText("Contact No:"+user_pNo);
            textView_latitude.setText("Latitude: "+user_lat);
            textView_logitude.setText("Longitude: "+user_lon);
            textView_total_job.setVisibility(View.GONE);
            textView_isActive.setVisibility(View.GONE);
        }

button_back_profile.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent intent1=new Intent(getApplicationContext(), MapsActivity.class);
        intent1.putExtra(IntentAttrHelper.USER_NAME_KEY,userNameIntent);
        intent1.putExtra(IntentAttrHelper.USER_TYPE_KEY, userTypeIntent);

        startActivity(intent1);finish();
    }
});

    }
}