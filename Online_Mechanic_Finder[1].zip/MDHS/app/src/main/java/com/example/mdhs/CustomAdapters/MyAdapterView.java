package com.example.mdhs.CustomAdapters;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.HelperClass.UserHolderHelper;
import com.example.mdhs.R;
import com.example.mdhs.Profile.MechanicUserViewProfile;
import com.example.mdhs.RecyclerView.RecyclerViewFindMechanic;

import java.util.List;

public class MyAdapterView extends RecyclerView.Adapter<MyAdapterView.ViewHolder>{
    /*
    create adapter for display all near mechanics with their
     username and their total distance away from driver
     */


    private List<UserHolderHelper>listData;

    public MyAdapterView(List<UserHolderHelper> listData) {
        this.listData = listData;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.user_item_card_view_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {

        UserHolderHelper ld=listData.get(position);
        holder.txtName.setText("Mec: "+ld.getUserName());
        //get distance up to 2 decimal points
        holder.txtDis.setText("Dis: "+String.format("%.2f", ld.getDistance())+"Km away");
        //set on click listener when detail icon is clicked
        holder.imageView_detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(), MechanicUserViewProfile.class);
                intent.putExtra(IntentAttrHelper.USER_NAME_KEY,listData.get(position).getUserName());
//                //get request response from mechanic fom  get name temp holder
//                intent.putExtra(REQUEST_STATUS_INTENT_KEY,listData.get(position).getName());
                intent.putExtra(IntentAttrHelper.ADDRESS_INTENT_KEY,listData.get(position).getAddress());
                intent.putExtra(IntentAttrHelper.CONTACT_INTENT_KEY,listData.get(position).getContact());
                intent.putExtra(IntentAttrHelper.TOTAL_JOB_INTENT_KEY,listData.get(position).gettJob());

                intent.putExtra(IntentAttrHelper.LATITUDE_INTENT_KEY,listData.get(position).getLatitude().toString());
                intent.putExtra(IntentAttrHelper.LONGITUDE_INTENT_KEY,listData.get(position).getLongitude().toString());
//                intent.putExtra(VIEW_HOLDER_TYPE_INTENT_KEY,"view");
                intent.putExtra(IntentAttrHelper.IS_ACTIVE_INTENT_KEY,listData.get(position).getActive());
                 intent.putExtra(IntentAttrHelper.WASH_SERVICE_INTENT_KEY,listData.get(position).getWashService());
                intent.putExtra(IntentAttrHelper.REPAIR_SERVICE_INTENT_KEY,listData.get(position).getRepairService());
                intent.putExtra(IntentAttrHelper.TYRE_SERVICE_INTENT_KEY,listData.get(position).getTyreService());

                v.getContext().startActivity(intent);
//                ((RecyclerViewFindMechanic)v.getContext()).finish();
            }
        });



    }

    @Override
    public int getItemCount() {
        return listData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView txtName,txtDis;
        private ImageView imageView_detail;
        public ViewHolder(View itemView) {
            super(itemView);
            txtName=(TextView)itemView.findViewById(R.id.nametxt_feedback_cardview_id);
            txtDis=(TextView)itemView.findViewById(R.id.distance_txt_feedback_cardview_id);
            imageView_detail=itemView.findViewById(R.id.imageView_detail_id);

        }
    }
}
