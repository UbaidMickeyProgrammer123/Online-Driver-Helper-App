package com.example.mdhs.Profile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mdhs.DataClasses.Payment;
import com.example.mdhs.FireBaseDB.FireBaseDAO;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.HelperClass.SharePreferenceAttrHelper;
import com.example.mdhs.MainActivity;
import com.example.mdhs.R;

public class DriverUserRequestProfileToMechanic extends AppCompatActivity {

    //initialize SharedPreferences object
    private SharedPreferences sharedPreferences;
    //initialize  firebase dao object
    FireBaseDAO fireBaseDAO;
    Payment payment;

    //create intent for set and get intent
//    this intent is for profile and My Adpater only




    //    declare user type string for get intent
    //declare button
    Button button_back_request_profile,button_request_accept,button_request_reject;
    //declare textview
EditText editText_desp_pay,editText_price,editText_bankDetail;

    TextView textView_userName,textView_phoneNo,textView_address,textView_total_job,textView_isActive,textView_latitude
            ,textView_logitude;
    //declare for temp holder
    String d_userName, d_address, d_pNo, d_tJob, d_lat, d_lon;
    String  reqStatus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_user_request_profile_to_mechanic);
        //initialize textview and button
        textView_userName=findViewById(R.id.textView_request_profile_userName_id);
        textView_address=findViewById(R.id.textView_request_profile_Address_id);
        textView_phoneNo=findViewById(R.id.textView_request_profile_contactNo_id);
        textView_total_job=findViewById(R.id.textView_request_profile_total_job_id);
        textView_isActive=findViewById(R.id.textView_request_profile_isActive_id);
        textView_latitude=findViewById(R.id.textView_request_profile_latitude_id);
        textView_logitude=findViewById(R.id.textView_request_profile_longitude_id);
        button_back_request_profile=findViewById(R.id.button_request_profile_back_id);
        button_request_accept=findViewById(R.id.button_request_profile_accept_id);
        button_request_reject=findViewById(R.id.button_request_profile_reject_id);

        //bind edit text
        editText_desp_pay =findViewById(R.id.editTextTextPersonName_mechanic_description_id);
        editText_price=findViewById(R.id.editTextTextPersonName2_mechanic_price_id);
        editText_bankDetail=findViewById(R.id.editTextTextPersonName3_mechanic_bankDetail_id);


//get intent data from main start screen
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        //create temp holder variables and get intent data
        d_userName =bundle.getString(IntentAttrHelper.USER_NAME_KEY,"UnKnown");
        d_address =bundle.getString(IntentAttrHelper.ADDRESS_INTENT_KEY,"UnKnown");
        d_pNo =bundle.getString(IntentAttrHelper.CONTACT_INTENT_KEY,"UnKnown");
        d_tJob =bundle.getString(IntentAttrHelper.TOTAL_JOB_INTENT_KEY,"UnKnown");
        reqStatus=bundle.getString(IntentAttrHelper.IS_ACTIVE_INTENT_KEY,"pending");
        d_lat =bundle.getString(IntentAttrHelper.LATITUDE_INTENT_KEY,"UnKnown");
        d_lon =bundle.getString(IntentAttrHelper.LONGITUDE_INTENT_KEY,"UnKnown");
        //set all textview data
        textView_userName.setText("Driver UserName\n "+ d_userName);
        textView_address.setText("Driver ADDRESS\n"+ d_address);
        textView_phoneNo.setText("Driver Contact No: "+ d_pNo);
         textView_total_job.setVisibility(View.GONE);
         textView_isActive.setText("Driver Request Status: "+reqStatus);
        textView_latitude.setText("Driver Latitude: "+ d_lat);
        textView_logitude.setText("Driver Logitude: "+ d_lon);

//user click on back button
        button_back_request_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent1);
                finish();
            }
        });
        //user click on button_request_accept button

        button_request_accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editText_desp_pay.getText().toString().equals("")
                ||editText_price.getText().toString().equals("")
                        ||editText_bankDetail.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(), "Please Complete Your Payment Detail", Toast.LENGTH_SHORT).show();
                }
                else{
                    sharedPreferences =getSharedPreferences("MyApp",MODE_PRIVATE);
                    String m_Username=sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_MECHANIC_KEY,"Nill_accept");
                    fireBaseDAO=new FireBaseDAO();
                    //update mechanic response
                    fireBaseDAO.setMechanicResponseAction(d_userName,m_Username,"Accept");
                    fireBaseDAO.updateTotalJobMechanic(m_Username,
                            getApplicationContext());

                    //set data on payment
                    payment=new Payment(d_userName,m_Username,editText_desp_pay.getText().toString(),
                            editText_price.getText().toString(),editText_bankDetail.getText().toString());
                    fireBaseDAO.insertPaymentDetailMechanic(payment);
                    Intent intent1=new Intent(getApplicationContext(), MainActivity.class);
                    Toast.makeText(getApplicationContext(), "Request Accept Successfully", Toast.LENGTH_SHORT).show();

                    startActivity(intent1);finish();
                }

            }
        });
        //user click on button_request_reject button

        button_request_reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sharedPreferences =getSharedPreferences("MyApp",MODE_PRIVATE);
                String m_Username=sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_MECHANIC_KEY,"Nill_reject");
                fireBaseDAO=new FireBaseDAO();
                //update mechanic response
                fireBaseDAO.setMechanicResponseAction(d_userName,m_Username,"Reject");
                Intent intent1=new Intent(getApplicationContext(), MainActivity.class);
                Toast.makeText(getApplicationContext(), "Request Rejected Successfully", Toast.LENGTH_SHORT).show();

                startActivity(intent1);finish();
            }
        });

    }

}