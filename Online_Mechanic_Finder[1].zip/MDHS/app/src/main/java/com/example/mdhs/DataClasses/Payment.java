package com.example.mdhs.DataClasses;

public class Payment {
    public Payment(String userPayBy, String userPayTo, String description, String price, String bankDetail) {
        this.userPayBy = userPayBy;
        this.userPayTo = userPayTo;
        this.description = description;
        this.price = price;
        this.bankDetail = bankDetail;
    }
public Payment(){

}
    String userPayBy,userPayTo,description,price,bankDetail;

    public String getUserPayBy() {
        return userPayBy;
    }

    public void setUserPayBy(String userPayBy) {
        this.userPayBy = userPayBy;
    }

    public String getUserPayTo() {
        return userPayTo;
    }

    public void setUserPayTo(String userPayTo) {
        this.userPayTo = userPayTo;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getBankDetail() {
        return bankDetail;
    }

    public void setBankDetail(String bankDetail) {
        this.bankDetail = bankDetail;
    }

}
