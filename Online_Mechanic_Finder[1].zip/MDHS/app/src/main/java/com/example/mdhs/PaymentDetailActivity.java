package com.example.mdhs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mdhs.DataClasses.Payment;
import com.example.mdhs.DataClasses.TowPerson;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.HelperClass.SharePreferenceAttrHelper;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class PaymentDetailActivity extends AppCompatActivity {
    Boolean verification=false;
TextView textView_payTo,textView_payBy,textView_descrip,textView_price,textView_acc_detail;
String payTo,payBy,descrip,price,acc_detail;
String paymentToType;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_detail);
        Intent intent1=getIntent();
        Bundle bundle=intent1.getExtras();
        payBy=bundle.getString(IntentAttrHelper.PAYMENT_BY_USERNAME_INTENT_KEY,"no user By");
        payTo=bundle.getString(IntentAttrHelper.PAYMENT_TO_USERNAME_INTENT_KEY,"no user To");
        paymentToType=bundle.getString(IntentAttrHelper.USER_TYPE_KEY,"no  user paymentToType");



        //bind xml data ids
        textView_payTo=findViewById(R.id.textView_payment_paymentTo_userName_id);
        textView_payBy=findViewById(R.id.textView_payment_paymentBy_userName_id);
        textView_descrip=findViewById(R.id.textView_payment_description_id);
        textView_price=findViewById(R.id.textView_payment_price_id);
        textView_acc_detail=findViewById(R.id.textView_payment_AccDetail_id);
        textView_payTo.setText("Loading ..");
        textView_payBy.setText("");
        textView_payTo.setText("");
        textView_descrip.setText("");
        textView_price.setText("");
        textView_acc_detail.setText("");

        if(paymentToType.equals("Mechanic")){
            getPaymentDetailMechanic();
        }
        if(paymentToType.equals("Tow")){
            getPaymentDetailTow();
        }


    }
    //    get data for getPaymentDetailMechanic
    public Boolean getPaymentDetailMechanic(){
        verification=false;
        final DatabaseReference nm= FirebaseDatabase.getInstance().getReference().child("DB").
                child("PaymentDetailMechanic").child(payTo);
        nm.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    for (DataSnapshot npsnapshot : dataSnapshot.getChildren()){
                        Payment l=npsnapshot.getValue(Payment.class);

                        if(payBy.equals(l.getUserPayBy())){
//check verification
                            verification=true;
                            textView_payTo.setText("..* Pay To *..\n"+l.getUserPayTo());
                            textView_payBy.setText("..* Pay By *..\n"+l.getUserPayBy());
                            textView_descrip.setText("Payment Description:  "+l.getDescription());
                            textView_price.setText("Total Charges:  "+l.getPrice());
                            textView_acc_detail.setText("Bank Detail:  "+l.getBankDetail());
                           return;

                        }

                    }
//if user already exit in firebase database then execute this if condition
                    if(!verification){
                        Toast.makeText(getApplicationContext(), "Payment is not save in db report to admin", Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        return verification;
    }
    //    get data for getPaymentDetailTow
    public Boolean getPaymentDetailTow(){
        verification=false;
        final DatabaseReference nm= FirebaseDatabase.getInstance().getReference().child("DB").
                child("PaymentDetailTow").child(payTo);
        nm.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    for (DataSnapshot npsnapshot : dataSnapshot.getChildren()){
                        Payment l=npsnapshot.getValue(Payment.class);

                        if(payBy.equals(l.getUserPayBy())){
//check verification
                            verification=true;
                            textView_payTo.setText("..* Pay To *..\n"+l.getUserPayTo());
                            textView_payBy.setText("..* Pay By *..\n"+l.getUserPayBy());
                            textView_descrip.setText("Payment Description:  "+l.getDescription());
                            textView_price.setText("Total Charges:  "+l.getPrice());
                            textView_acc_detail.setText("Bank Detail:  "+l.getBankDetail());
                            return;

                        }

                    }
//if user already exit in firebase database then execute this if condition
                    if(!verification){
                        Toast.makeText(getApplicationContext(), "Payment is not save in db please report to admin", Toast.LENGTH_SHORT).show();
                    }

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        return verification;
    }
}