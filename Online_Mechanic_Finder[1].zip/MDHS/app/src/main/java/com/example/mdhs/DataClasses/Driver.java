package com.example.mdhs.DataClasses;

public class Driver extends Person{

   public Driver(){
       super("Null", "Null", "Null", "Null", "Null","Null",0.00,0.00);

   }
    public Driver(String UserName, String name, String contact, String pass, String rePass, String address, Double latitude, Double longitude) {
        super(UserName, name, contact, pass, rePass, address, latitude, longitude);
    }
}
