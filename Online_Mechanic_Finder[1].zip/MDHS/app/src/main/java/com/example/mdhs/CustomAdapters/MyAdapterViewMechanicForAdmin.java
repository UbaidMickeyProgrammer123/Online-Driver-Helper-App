package com.example.mdhs.CustomAdapters;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mdhs.AdminChoiceActivity;
import com.example.mdhs.DataClasses.Mechanic;
import com.example.mdhs.FireBaseDB.FireBaseDAO;
import com.example.mdhs.RecyclerView.FeedbackMechanicRecyclerView;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.R;
import com.example.mdhs.RecyclerView.ViewUserForModifyByAdminRecyclerView;

import java.util.List;

public class MyAdapterViewMechanicForAdmin extends RecyclerView.Adapter<MyAdapterViewMechanicForAdmin.ViewHolder>{
FireBaseDAO fireBaseDAO;


/*
    create adapter for display all mechanics with their
     username and their contact number for deletion or view feedback  by admin
     */


    private List<Mechanic>listData;

    public MyAdapterViewMechanicForAdmin(List<Mechanic> listData) {
        this.listData = listData;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.feedback_item_card_view_adminlayout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {

        Mechanic ld=listData.get(position);
        holder.txtName.setText("Mec: "+ld.getUserName());
        //get distance up to 2 decimal points
        holder.txtDis.setText("P-No: "+ld.getContact());
        //set on click listener when detail icon is clicked
        holder.imageView_detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(), FeedbackMechanicRecyclerView.class);
                intent.putExtra(IntentAttrHelper.USER_NAME_KEY,listData.get(position).getUserName());
                v.getContext().startActivity(intent);

//                ((MyAdapterView)v.getContext()).finish();
            }
        });

        holder.imageView_delete_mechanic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                fireBaseDAO=new FireBaseDAO();
                fireBaseDAO.deleteMechanic(listData.get(position).getUserName(),v.getContext());



            }
        });



    }

    @Override
    public int getItemCount() {
        return listData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView txtName,txtDis;
        private ImageView imageView_detail,imageView_delete_mechanic;
        public ViewHolder(View itemView) {
            super(itemView);
            txtName=(TextView)itemView.findViewById(R.id.nametxt_admin_view_feedback_cardview_id);
            txtDis=(TextView)itemView.findViewById(R.id.distance_txt_admin_view_feedback_cardview_id);
            imageView_detail=itemView.findViewById(R.id.imageView_admin_view_feedback_detail_id);
            imageView_delete_mechanic=itemView.findViewById(R.id.imageView_admin_view_feedback_delete_mechanic_id);

        }
    }
}
