package com.example.mdhs.CustomAdapters;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mdhs.DataClasses.ServiceRequest;
import com.example.mdhs.FeedbackForm.FeedbackFormForTowPersonActivity;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.R;
import com.example.mdhs.RecyclerView.ResponseTowPersonRecyclerViewActivity;

import java.util.List;

public class MyAdapterTowPeronResponce extends RecyclerView.Adapter<MyAdapterTowPeronResponce.ViewHolder>{
    /*
    create adapter for display all near mechanics responses with their
     username and their response status from driver
     */

Context context;




    private List<ServiceRequest>listData;

    public MyAdapterTowPeronResponce(List<ServiceRequest> listData, Context context) {
        this.listData = listData;
        this.context=context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.user_item_list_mechanic_responce_feedback_icon_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {

        ServiceRequest ld=listData.get(position);
        holder.txtName.setText("TowPerson: "+ld.getReqToUserName());
        //get distance up to 2 decimal points
        holder.txtDis.setText("Status: "+ld.getReqToresponce());
        if(ld.getReqToresponce().equals("Accept")){
//            //update mechanic user is active
//            fireBaseDAO=new FireBaseDAO();
//            fireBaseDAO.updateMechanicIsActiveStatus(ld.getReqToUserName(),true,context);

//set on click listener when detail icon is clicked
            holder.imageView_detail.setVisibility(View.VISIBLE);
        }
        else{
            holder.imageView_detail.setVisibility(View.GONE);
        }

        //if user click on feedback icon
        holder.imageView_detail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(v.getContext(), FeedbackFormForTowPersonActivity.class);
                intent.putExtra(IntentAttrHelper.USER_NAME_KEY,listData.get(position).getReqToUserName());

                intent.putExtra(IntentAttrHelper.ADDRESS_INTENT_KEY,listData.get(position).getReqToAddress());
                intent.putExtra(IntentAttrHelper.CONTACT_INTENT_KEY,listData.get(position).getReqToContact());



//                intent.putExtra("btn_type","update");
                v.getContext().startActivity(intent);
//                ((ResponseTowPersonRecyclerViewActivity)v.getContext()).finish();
            }
        });






    }

    @Override
    public int getItemCount() {
        return listData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView txtName,txtDis;
        private ImageView imageView_detail;
        public ViewHolder(View itemView) {
            super(itemView);
            txtName=(TextView)itemView.findViewById(R.id.nametxt_feedback_cardview_id);
            txtDis=(TextView)itemView.findViewById(R.id.distance_txt_feedback_cardview_id);
            imageView_detail=itemView.findViewById(R.id.imageView_detail_id);

        }
    }
}
