package com.example.mdhs.RecyclerView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.example.mdhs.CustomAdapters.MyAdapterMechanicResponce;
import com.example.mdhs.DataClasses.ServiceRequest;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MechanicResponseRecylerView extends AppCompatActivity {
//    MechanicResponseRecylerView class for display all towPerson response for particular driver
//    declaration var
    private List<ServiceRequest> serviceRequestList;
    RecyclerView recyclerView_response_mechanic;
    String userType,userName;
    MyAdapterMechanicResponce myAdapterMechanicResponce;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mechanic_response_recyler_view);


        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
//        declare and initialize userType String to store intent USER_TYPE_KEY value

//        declare and initialize userType String to store intent USER_TYPE_KEY value
        userType = bundle.getString(IntentAttrHelper.USER_TYPE_KEY, "NILL");
        userName = bundle.getString(IntentAttrHelper.USER_NAME_KEY, "NILL");

//bind recycler view
        recyclerView_response_mechanic=findViewById(R.id.MechanicResponceRecyView_layout_id);
        recyclerView_response_mechanic.setHasFixedSize(true);
        recyclerView_response_mechanic.setLayoutManager(new LinearLayoutManager(this));
        serviceRequestList=new ArrayList<>();
        //get all towPerson response
        getMechanicResponse();
    }
    //get all towPerson response of particular driver by its name

    private void getMechanicResponse() {
        final DatabaseReference nm= FirebaseDatabase.getInstance().getReference().child("DB").
                child("ResponseFromMechanic").child(userName);
        nm.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    for (DataSnapshot npsnapshot : dataSnapshot.getChildren()){
                        ServiceRequest l=npsnapshot.getValue(ServiceRequest.class);
                        serviceRequestList.add(l)   ;
                    }
                    myAdapterMechanicResponce=new MyAdapterMechanicResponce(serviceRequestList,getApplicationContext());
                    recyclerView_response_mechanic.setAdapter(myAdapterMechanicResponce);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}