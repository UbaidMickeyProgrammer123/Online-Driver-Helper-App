package com.example.mdhs.Profile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mdhs.DataClasses.ServiceRequest;
import com.example.mdhs.FireBaseDB.FireBaseDAO;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.HelperClass.SharePreferenceAttrHelper;
import com.example.mdhs.MapGoogleActivity.MapsActivity;
import com.example.mdhs.RecyclerView.FeedbackMechanicRecyclerView;
import com.example.mdhs.RecyclerView.RecyclerViewFindMechanic;
import com.example.mdhs.R;

public class MechanicUserViewProfile extends AppCompatActivity {
//declare SharedPreferences  object
    private SharedPreferences sharedPreferences;
    //declare  firebase dao object
    FireBaseDAO fireBaseDAO;
    //declare Service Request object
    private ServiceRequest serviceRequest;
    //declare button
    Button button_back_profile,button_hire_mechanic,button_view_feedback;
    //declare textview
TextView textView_userName,textView_phoneNo,textView_address,textView_total_job,textView_isActive,textView_latitude
        ,textView_logitude;
//declare for temp holder
    String m_userName, m_address, m_pNo, m_tJob,m_lat, m_lon;
    Boolean isActive,washService,repairService,tyreService;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mechanic_user_profile);
//initialize textview and button
        textView_userName=findViewById(R.id.textView_profile_userName_id);
        textView_address=findViewById(R.id.textView_profile_Address_id);
        textView_phoneNo=findViewById(R.id.textView_profile_contactNo_id);
        textView_total_job=findViewById(R.id.textView_profile_total_job_id);
        textView_isActive=findViewById(R.id.textView_profile_isActive_id);
        textView_latitude=findViewById(R.id.textView_profile_latitude_id);
        textView_logitude=findViewById(R.id.textView_profile_longitude_id);
        button_back_profile=findViewById(R.id.button_profile_back_id);
        button_hire_mechanic=findViewById(R.id.button_profile_hireNow_id);
        button_view_feedback=findViewById(R.id.button_view_feedback_from_profile_id);

//get intent data from main start screen
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        //create temp holder variables

        m_userName =bundle.getString(IntentAttrHelper.USER_NAME_KEY,"UnKnown");
        m_address =bundle.getString(IntentAttrHelper.ADDRESS_INTENT_KEY,"UnKnown");
        m_pNo =bundle.getString(IntentAttrHelper.CONTACT_INTENT_KEY,"UnKnown");
        m_tJob =bundle.getString(IntentAttrHelper.TOTAL_JOB_INTENT_KEY,"UnKnown");
        isActive=bundle.getBoolean(IntentAttrHelper.IS_ACTIVE_INTENT_KEY,false);
        m_lat=bundle.getString(IntentAttrHelper.LATITUDE_INTENT_KEY,"UnKnown");
        m_lon =bundle.getString(IntentAttrHelper.LONGITUDE_INTENT_KEY,"UnKnown");
        washService=bundle.getBoolean(IntentAttrHelper.WASH_SERVICE_INTENT_KEY,false);
        repairService=bundle.getBoolean(IntentAttrHelper.REPAIR_SERVICE_INTENT_KEY,false);
        tyreService=bundle.getBoolean(IntentAttrHelper.TYRE_SERVICE_INTENT_KEY,false);

        String services = "";
        //check services available
        if(washService.equals(true)){
            services=services+" S: wash,";
        }
        if(repairService.equals(true)){
            services=services+" S: repair,";
        }
        if(tyreService.equals(true)){
            services=services+" S: tyre";
        }

        textView_userName.setText("UserName: "+ m_userName);
        textView_address.setText("ADDRESS\n"+ m_address);
        textView_phoneNo.setText("Contact No: "+ m_pNo);
        textView_total_job.setText("Total Job: "+ m_tJob+"\n\nServices Available are: "+services);
        //check condition is active
        if(isActive.equals(true)) textView_isActive.setText("isActive: "+"true");
        else textView_isActive.setText("isActive: "+"false");
        textView_latitude.setText("Latitude: "+m_lat);
        textView_logitude.setText("Logitude: "+ m_lon);
        //when user click back press
button_back_profile.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent intent1=new Intent(getApplicationContext(), RecyclerViewFindMechanic.class);
        intent1.putExtra(IntentAttrHelper.LATITUDE_INTENT_KEY,Double.valueOf(m_lat));
        intent1.putExtra(IntentAttrHelper.LONGITUDE_INTENT_KEY,Double.valueOf(m_lon));
        intent1.putExtra(IntentAttrHelper.USER_NAME_KEY, m_userName);
        intent1.putExtra(IntentAttrHelper.USER_TYPE_KEY,"Driver");
        startActivity(intent1);
        finish();
    }
});

//press hire request button
        button_hire_mechanic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //get data from share preference

                //set already login key and email key on share preference
                sharedPreferences =getSharedPreferences("MyApp",MODE_PRIVATE);
                String d_name=sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_DRIVER_KEY,"Nill");
                String d_contact=sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_CONTACT_DRIVER_KEY,"Nill");
                String d_address=sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_ADDRESS_DRIVER_KEY,"Nill");
                String d_lat=sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LATITUDE_DRIVER_KEY,"Nill");
                String d_lon=sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LONGITUDE_DRIVER_KEY,"Nill");
                //initialize object of Service Request
                serviceRequest=new ServiceRequest(d_name,d_contact,d_address,d_lat,d_lon,
                        m_userName,
                        m_pNo,
                        m_address,
                        m_lat,
                        m_lon
                        ,"pending");
                fireBaseDAO=new FireBaseDAO();
                //insert service request object on firebase database
                fireBaseDAO.setServiceRequestToMechanic(serviceRequest);
                Intent intent1=new Intent(getApplicationContext(), MapsActivity.class);
                intent1.putExtra(IntentAttrHelper.USER_TYPE_KEY,"Driver");
                intent1.putExtra(IntentAttrHelper.USER_NAME_KEY,d_name);
                Toast.makeText(getApplicationContext(), "Hire Mechanic Successfully", Toast.LENGTH_SHORT).show();

                startActivity(intent1);finish();
            }
        });

//when user click on view feedback of particular mechanic
        button_view_feedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(getApplicationContext(), FeedbackMechanicRecyclerView.class);
                intent1.putExtra(IntentAttrHelper.USER_NAME_KEY,m_userName);
                startActivity(intent1);
            }
        });

    }
}