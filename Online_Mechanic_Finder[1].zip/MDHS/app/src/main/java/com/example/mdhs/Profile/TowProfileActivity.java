package com.example.mdhs.Profile;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mdhs.DataClasses.ServiceRequest;
import com.example.mdhs.FireBaseDB.FireBaseDAO;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.HelperClass.SharePreferenceAttrHelper;
import com.example.mdhs.MapGoogleActivity.MapsActivity;
import com.example.mdhs.R;
import com.example.mdhs.RecyclerView.FeebackTowPersonRecyclerView;
import com.example.mdhs.RecyclerView.FeedbackMechanicRecyclerView;
import com.example.mdhs.RecyclerView.RecyclerViewFindTowPerson;

public class TowProfileActivity extends AppCompatActivity {
    //declare SharedPreferences  object
    private SharedPreferences sharedPreferences;
    //declare  firebase dao object
    private FireBaseDAO fireBaseDAO_Obj;
    //declare Service Request object
    private ServiceRequest serviceRequest;
    //declare button
    private Button button_back_profile, button_hire_towPerson,button_view_feedback;
    //declare textview
    private TextView textView_userName,textView_phoneNo,textView_address,textView_total_job,textView_isActive,textView_latitude
            ,textView_logitude;
    //declare for temp holder
    private String tow_userName, tow_address, tow_pNo, tow_tJob, tow_lat, tow_lon;
    private Boolean towisActive;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tow_profile);

        //initialize textview and button
        textView_userName=findViewById(R.id.textView_Tow_profile_userName_id);
        textView_address=findViewById(R.id.textView_Tow_profile_Address_id);
        textView_phoneNo=findViewById(R.id.textView_Tow_profile_contactNo_id);
        textView_total_job=findViewById(R.id.textView_Tow_profile_total_job_id);
        textView_isActive=findViewById(R.id.textView_Tow_profile_isActive_id);
        textView_latitude=findViewById(R.id.textView_Tow_profile_latitude_id);
        textView_logitude=findViewById(R.id.textView_Tow_profile_longitude_id);
        button_back_profile=findViewById(R.id.button_Tow_profile_back_id);
        button_hire_towPerson =findViewById(R.id.button_Tow_profile_hireNow_id);
        button_view_feedback=findViewById(R.id.button_view_feedback_from_Tow_profile_id);

//get intent data from main start screen
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        //create temp holder variables

        tow_userName =bundle.getString(IntentAttrHelper.USER_NAME_KEY,"UnKnown");
        tow_address =bundle.getString(IntentAttrHelper.ADDRESS_INTENT_KEY,"UnKnown");
        tow_pNo =bundle.getString(IntentAttrHelper.CONTACT_INTENT_KEY,"UnKnown");
        tow_tJob =bundle.getString(IntentAttrHelper.TOTAL_JOB_INTENT_KEY,"UnKnown");
        towisActive =bundle.getBoolean(IntentAttrHelper.IS_ACTIVE_INTENT_KEY,false);
        tow_lat =bundle.getString(IntentAttrHelper.LATITUDE_INTENT_KEY,"UnKnown");
        tow_lon =bundle.getString(IntentAttrHelper.LONGITUDE_INTENT_KEY,"UnKnown");
        textView_userName.setText("Tow UserName: "+ tow_userName);
        textView_address.setText("Tow ADDRESS\n"+ tow_address);
        textView_phoneNo.setText("Tow Contact No: "+ tow_pNo);
        textView_total_job.setText("Tow Total Job: "+ tow_tJob);
        //check condition is active
        if(towisActive.equals(true)) textView_isActive.setText("towisActive: "+"true");
        else textView_isActive.setText("towisActive: "+"false");
        textView_latitude.setText("Tow Latitude: "+ tow_lat);
        textView_logitude.setText("Tow Logitude: "+ tow_lon);
        //when user click back press
        button_back_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(getApplicationContext(), RecyclerViewFindTowPerson.class);
                intent1.putExtra(IntentAttrHelper.LATITUDE_INTENT_KEY,Double.valueOf(tow_lat));
                intent1.putExtra(IntentAttrHelper.LONGITUDE_INTENT_KEY,Double.valueOf(tow_lon));
                intent1.putExtra(IntentAttrHelper.USER_NAME_KEY, tow_userName);
                intent1.putExtra(IntentAttrHelper.USER_TYPE_KEY,"Driver");
                startActivity(intent1);
                finish();
            }
        });

//press hire request button
        button_hire_towPerson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    //get data from share preference

                    //set already login key and email key on share preference
                    sharedPreferences =getSharedPreferences("MyApp",MODE_PRIVATE);
                    String d_name=sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_DRIVER_KEY,"Nill");
                    String d_contact=sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_CONTACT_DRIVER_KEY,"Nill");
                    String d_address=sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_ADDRESS_DRIVER_KEY,"Nill");
                    String d_lat=sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LATITUDE_DRIVER_KEY,"Nill");
                    String d_lon=sharedPreferences.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_LONGITUDE_DRIVER_KEY,"Nill");
                    //initialize object of Service Request
                    serviceRequest=new ServiceRequest(d_name,d_contact,d_address,d_lat,d_lon,
                            tow_userName,
                            tow_pNo,
                            tow_address,
                            tow_lat,
                            tow_lon
                            ,"pending");
                    fireBaseDAO_Obj=new FireBaseDAO();
                    //insert service request object on firebase database
                    fireBaseDAO_Obj.setServiceRequestToTowPerson(serviceRequest,getApplicationContext());
                    Intent intent1=new Intent(getApplicationContext(), MapsActivity.class);
                    intent1.putExtra(IntentAttrHelper.USER_TYPE_KEY,"Driver");
                    intent1.putExtra(IntentAttrHelper.USER_NAME_KEY,d_name);
                    Toast.makeText(getApplicationContext(), "Hire Tow Person Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(intent1);finish();
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Hire Tow Person Error", Toast.LENGTH_SHORT).show();
                }


            }
        });

//when user click on view feedback of particular mechanic
        button_view_feedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(getApplicationContext(), FeebackTowPersonRecyclerView.class);
                intent1.putExtra(IntentAttrHelper.USER_NAME_KEY, tow_userName);
                startActivity(intent1);
            }
        });

    }
    }
