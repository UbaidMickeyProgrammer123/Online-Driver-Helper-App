package com.example.mdhs.RecyclerView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mdhs.CustomAdapters.MyAdapterMechanicResponce;
import com.example.mdhs.CustomAdapters.MyAdapterViewMechanicForAdmin;
import com.example.mdhs.CustomAdapters.MyAdapterViewTowPersonForAdmin;
import com.example.mdhs.DataClasses.Mechanic;
import com.example.mdhs.DataClasses.ServiceRequest;
import com.example.mdhs.DataClasses.TowPerson;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ViewUserForModifyByAdminRecyclerView extends AppCompatActivity {
//    create ViewUserForModifyByAdminRecyclerView for display all towPerson for delete
//    or view feedback of particular towPerson
    //declare mechanicList, recyclerView,myAdapterViewMechanicForAdmin
    private List<Mechanic> mechanicList;
    private List<TowPerson> towPersonList;
    private String userType="";
    RecyclerView recyclerView;
    MyAdapterViewMechanicForAdmin myAdapterViewMechanicForAdmin;
    MyAdapterViewTowPersonForAdmin  myAdapterViewTowPersonForAdmin;
    TextView textView_user_modify_id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mechanic_list_feed_back_recycler_view);
        //get intent
        Intent intent=getIntent();
        Bundle bundle=intent.getExtras();
        userType=bundle.getString(IntentAttrHelper.USER_TYPE_KEY,"no user Admin");
//bind recyclerView from xml
        recyclerView=findViewById(R.id.recylerViewListMechanicForAdmin_layout_id);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        //initialize mechanicList
textView_user_modify_id=findViewById(R.id.textView13_user_modifyAdmin_id);

        mechanicList=new ArrayList<>();
        towPersonList=new ArrayList<>();
        //get all mechanics method
        if(userType.equals("Mechanic")){
            textView_user_modify_id.setText("Mechanic List");
            getAllMechanic();
        }
        if(userType.equals("Tow")){
            textView_user_modify_id.setText("Tow List");

            getAllTwoPerson();
        }

    }

    private void getAllMechanic() {
        final DatabaseReference nm= FirebaseDatabase.getInstance().getReference().child("DB").
                child("Mechanic");
        nm.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    for (DataSnapshot npsnapshot : dataSnapshot.getChildren()){
                        Mechanic l=npsnapshot.getValue(Mechanic.class);
                        //add all mechanics and set in MyAdapterViewMechanicForAdmin
                           mechanicList.add(l) ;
                    }

                    myAdapterViewMechanicForAdmin=new MyAdapterViewMechanicForAdmin(mechanicList);
                    recyclerView.setAdapter(myAdapterViewMechanicForAdmin);


                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    private void getAllTwoPerson() {
        final DatabaseReference nm= FirebaseDatabase.getInstance().getReference().child("DB").
                child("Tow");
        nm.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    for (DataSnapshot npsnapshot : dataSnapshot.getChildren()){
                        TowPerson l=npsnapshot.getValue(TowPerson.class);
                        //add all tow and set in MyAdapterViewMechanicForAdmin
                        towPersonList.add(l) ;
                    }

                    myAdapterViewTowPersonForAdmin=new MyAdapterViewTowPersonForAdmin(towPersonList);
                    recyclerView.setAdapter(myAdapterViewTowPersonForAdmin);


                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}