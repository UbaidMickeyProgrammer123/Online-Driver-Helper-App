package com.example.mdhs.DataClasses;

public class FeedBack {
    String userNameFeedBackBy;
    String userNameFeedBackTo;
    String comment;
    public String getUserNameFeedBackBy() {
        return userNameFeedBackBy;
    }

    public void setUserNameFeedBackBy(String userNameFeedBackBy) {
        this.userNameFeedBackBy = userNameFeedBackBy;
    }

    public String getUserNameFeedBackTo() {
        return userNameFeedBackTo;
    }

    public void setUserNameFeedBackTo(String userNameFeedBackTo) {
        this.userNameFeedBackTo = userNameFeedBackTo;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }


    public FeedBack(String userNameFeedBackBy, String userNameFeedBackTo, String comment) {

        this.userNameFeedBackBy = userNameFeedBackBy;
        this.userNameFeedBackTo = userNameFeedBackTo;
        this.comment = comment;
    }
    public FeedBack(){

    }

}
