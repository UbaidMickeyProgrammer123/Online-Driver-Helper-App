package com.example.mdhs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.mdhs.Account.Login_Page;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.HelperClass.SharePreferenceAttrHelper;
import com.example.mdhs.MapGoogleActivity.MapsActivity;
import com.example.mdhs.RecyclerView.ViewUserForModifyByAdminRecyclerView;

public class AdminChoiceActivity extends AppCompatActivity {
    // Creating variable declaration of views for bind to get XML ids of main page.
    ImageView mechanic_image_view,tow_image_view;
    // Creating variable declaration of layouts for bind to get XML ids of main page.
    LinearLayout linearLayout_mechanic,linearLayout_tow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_choice);
//         Getting XML ids from main UI to the main Java Class
        mechanic_image_view=findViewById(R.id.imageView_mechanic_admin_id);
        tow_image_view=findViewById(R.id.imageView_tow_admin_id);
        linearLayout_mechanic=findViewById(R.id.linear_layout_mechanic_admin_id);
        linearLayout_tow=findViewById(R.id.linear_layout_tow_admin_id);

        // set on click listener when user click on mechanic_image_view
        mechanic_image_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getApplicationContext(), ViewUserForModifyByAdminRecyclerView.class);
                intent.putExtra(IntentAttrHelper.USER_TYPE_KEY,"Mechanic");
                startActivity(intent);
            }
        });

//        when user click on linearLayout_mechanic red icon
        linearLayout_mechanic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getApplicationContext(),ViewUserForModifyByAdminRecyclerView.class);
                intent.putExtra(IntentAttrHelper.USER_TYPE_KEY,"Mechanic");
                startActivity(intent);
            }
        });
        // set on click listener when user click on mechanic_image_view
        tow_image_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getApplicationContext(),ViewUserForModifyByAdminRecyclerView.class);
                intent.putExtra(IntentAttrHelper.USER_TYPE_KEY,"Tow");
                startActivity(intent);
            }
        });

//        when user click on linearLayout_mechanic red icon
        linearLayout_tow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getApplicationContext(),ViewUserForModifyByAdminRecyclerView.class);
                intent.putExtra(IntentAttrHelper.USER_TYPE_KEY,"Tow");
                startActivity(intent);
            }
        });
    }
}