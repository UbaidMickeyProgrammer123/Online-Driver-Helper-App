package com.example.mdhs.CustomAdapters;


import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mdhs.DataClasses.FeedBack;
import com.example.mdhs.R;

import java.util.List;

public class MyAdapterViewFeedback extends RecyclerView.Adapter<MyAdapterViewFeedback.ViewHolder>{
/*
    create adapter for display feedbacks of specific mechanics with their
     driver username and his comment
     */


//    private String VIEW_HOLDER_TYPE_INTENT_KEY="view_holder_type_intent_key";


    private List<FeedBack>listData;

    public MyAdapterViewFeedback(List<FeedBack> listData) {
        this.listData = listData;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.feedback_item_card_view_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {

        FeedBack ld=listData.get(position);
        holder.txtName.setText("Driver : "+ld.getUserNameFeedBackBy());
        //get distance up to 2 decimal points
        holder.txtDis.setText("Comment : "+ld.getComment());
        //set on click listener when detail icon is clicked




    }

    @Override
    public int getItemCount() {
        return listData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        private TextView txtName,txtDis;

        public ViewHolder(View itemView) {
            super(itemView);
            txtName=(TextView)itemView.findViewById(R.id.nametxt_feedback_cardview_id);
            txtDis=(TextView)itemView.findViewById(R.id.distance_txt_feedback_cardview_id);


        }
    }
}
