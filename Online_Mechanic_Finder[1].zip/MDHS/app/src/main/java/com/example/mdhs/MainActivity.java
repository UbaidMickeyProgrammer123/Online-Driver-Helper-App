package com.example.mdhs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.mdhs.Account.Login_Page;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.HelperClass.SharePreferenceAttrHelper;
import com.example.mdhs.MapGoogleActivity.MapsActivity;
import com.example.mdhs.RecyclerView.ViewUserForModifyByAdminRecyclerView;

public class MainActivity extends AppCompatActivity {
//create keys for share preference

//initialization  on share preference object
    SharedPreferences sh;
// Creating variable declaration of views for bind to get XML ids of main page.
    ImageView mechanic_image_view,driver_image_view,admin_image_view,tow_image_view;
// Creating variable declaration of layouts for bind to get XML ids of main page.
    LinearLayout linearLayout_mechanic,linearLayout_driver,linearLayout_tow,linearLayout_admin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
// initialize Getting XML ids from main UI to the main Java Class
        mechanic_image_view=findViewById(R.id.imageView_mechanic_id);
        driver_image_view=findViewById(R.id.imageView_driver_id);
        admin_image_view=findViewById(R.id.imageView_admin_id);
        tow_image_view=findViewById(R.id.imageView_tow_id);
        linearLayout_mechanic=findViewById(R.id.linear_layout_mechanic_id);
        linearLayout_driver=findViewById(R.id.linear_layout_driver_id);
        linearLayout_tow=findViewById(R.id.linear_layout_tow_id);
        linearLayout_admin=findViewById(R.id.linear_layout_admin_id);
        /*::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/
        /*::                                                                         :*/
        /*::
        /*:: Note:
        /*:: This is the MainActivity where user start their involvement in app      :*/
        /*:: these click listener are used when user press any image button or any   :*/
        /*:: click listener
        /*::
        /*::  "f"<----- this parameter used for check when user cannot login in system
        /*:: if user already login then direct move to MapActivity page
        /*:: otherwise user move towards login page
        /*::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::*/

// set on click listener when user click on mechanic_image_view
 mechanic_image_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //check value exit in share preferences or not
                sh = getSharedPreferences("MyApp", MODE_PRIVATE);
// assigning value to cre_login variable
                String cre_login = sh.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_MECHANIC_LOGIN_CHECK, "f");
// checking credentials for login whether it exists in database or not!!
                if (!cre_login.equals("f")) {
// creating Intent object and start Mapsactivity by passing Intent
                    Intent intent = new Intent(getApplicationContext(), MapsActivity.class);
                    intent.putExtra(IntentAttrHelper.USER_TYPE_KEY, "Mechanic");
                    intent.putExtra(IntentAttrHelper.USER_NAME_KEY, sh.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_MECHANIC_KEY, "no_m_name"));
                    startActivity(intent);

                }
//if mechanic cannot already login
                else if (cre_login.equals("f")) {
// creating Intent object and start Login Page by passing Intent
                    Intent intent = new Intent(getApplicationContext(), Login_Page.class);
                    intent.putExtra(IntentAttrHelper.USER_TYPE_KEY, "Mechanic");
                    startActivity(intent);
                }
            }
        });

//        when user click on linearLayout_mechanic red icon
        linearLayout_mechanic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //check value exit in share preferences or not
                sh=getSharedPreferences("MyApp",MODE_PRIVATE);
                String cre_login=sh.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_MECHANIC_LOGIN_CHECK,"f");
// if mechanic already login
                if(!cre_login.equals("f"))
                {
// creating Intent object and start Mapsactivity by passing Intent
                    Intent intent =new Intent(getApplicationContext(),MapsActivity.class);
                    intent.putExtra(IntentAttrHelper.USER_TYPE_KEY,"Mechanic");
                    intent.putExtra(IntentAttrHelper.USER_NAME_KEY,sh.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_MECHANIC_KEY,"no_m_name"));
                    startActivity(intent);

                }

// if mechanic is not already login
                else if(cre_login.equals("f"))
                {
// creating Intent object and start Login_Page by passing Intent
                    Intent intent = new Intent(getApplicationContext(), Login_Page.class);
                    intent.putExtra(IntentAttrHelper.USER_TYPE_KEY, "Mechanic");
                    startActivity(intent);
                }
            }
        });

// set on click Image button when user click on driver_image_view
        driver_image_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//check value exit in share preferences or not
                sh=getSharedPreferences("MyApp",MODE_PRIVATE);
                String cre_login=sh.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_DRIVER_LOGIN_CHECK,"f");
// if driver already login
                if(!cre_login.equals("f"))
                {
// creating Intent object and start MapsActivity by passing Intent
                    Intent intent =new Intent(getApplicationContext(),MapsActivity.class);
                    intent.putExtra(IntentAttrHelper.USER_TYPE_KEY,"Driver");
                    intent.putExtra(IntentAttrHelper.USER_NAME_KEY,
                            sh.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_DRIVER_KEY,"no_d_name"));
                    startActivity(intent);

                }
// if driver not already login
                else if(cre_login.equals("f"))  {
// creating Intent object and start Login_Page by passing Intent
                    Intent intent = new Intent(getApplicationContext(), Login_Page.class);
                    intent.putExtra(IntentAttrHelper.USER_TYPE_KEY, "Driver");
                    startActivity(intent);
                }
            }
        });
//layout click listener
        linearLayout_driver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//check value exit in share preferences or not
                sh=getSharedPreferences("MyApp",MODE_PRIVATE);
                String cre_login=sh.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_DRIVER_LOGIN_CHECK,"f");
// if driver already login
                if(!cre_login.equals("f"))
                {
// creating Intent object and start MapsActivity by passing Intent
                    Intent intent =new Intent(getApplicationContext(),MapsActivity.class);
                    intent.putExtra(IntentAttrHelper.USER_TYPE_KEY,"Driver");
                    intent.putExtra(IntentAttrHelper.USER_NAME_KEY,
                            sh.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_DRIVER_KEY,"no_d_name"));
                    startActivity(intent);

                }
// if driver not already login
                else if(cre_login.equals("f"))  {
                    Intent intent = new Intent(getApplicationContext(), Login_Page.class);
                    intent.putExtra(IntentAttrHelper.USER_TYPE_KEY, "Driver");
                    startActivity(intent);
                }
            }
        });

// set on click listener when user click on admin_image_view
        admin_image_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//check value exit in share preferences or not
                sh=getSharedPreferences("MyApp",MODE_PRIVATE);
                String  cre_login=sh.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_ADMIN_LOGIN_CHECK,"f");
// if admin already login
                if(!cre_login.equals("f"))
                {
// creating Intent object and start ViewUserForModifyByAdminRecyclerView by passing Intent
                    Intent intent =new Intent(getApplicationContext(), ViewUserForModifyByAdminRecyclerView.class);
                    intent.putExtra(IntentAttrHelper.USER_TYPE_KEY,"Admin");
//hard code user name
                    startActivity(intent);
                }
// if admin not already login
                else if(cre_login.equals("f"))  {
// creating Intent object and start Login_Page by passing Intent
                    Intent intent = new Intent(getApplicationContext(), Login_Page.class);
                    intent.putExtra(IntentAttrHelper.USER_TYPE_KEY, "Admin");
                    startActivity(intent);

//                Toast.makeText(getApplicationContext(), "hello", Toast.LENGTH_SHORT).show();
                }
            }
        });
//linearLayout_admin click listener
        linearLayout_admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //check value exit in share preferences or not
                sh=getSharedPreferences("MyApp",MODE_PRIVATE);
                String  cre_login=sh.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_ADMIN_LOGIN_CHECK,"f");
// if admin already login
                if(!cre_login.equals("f"))
                {
// creating Intent object and start ViewUserForModifyByAdminRecyclerView by passing Intent
                    Intent intent =new Intent(getApplicationContext(), AdminChoiceActivity.class);
                    intent.putExtra(IntentAttrHelper.USER_TYPE_KEY,"Admin");
                    //hard cord user name
                    startActivity(intent);
                }
// if admin not already login
                else if(cre_login.equals("f"))  {
// creating Intent object and start Login_Page by passing Intent
                    Intent intent = new Intent(getApplicationContext(), Login_Page.class);
                    intent.putExtra(IntentAttrHelper.USER_TYPE_KEY, "Admin");
                    startActivity(intent);
                }
            }
        });

// set on click listener when user click on tow_service_image_view
        tow_image_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//check value exit in share preferences or not
                sh=getSharedPreferences("MyApp",MODE_PRIVATE);
                String cre_login=sh.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_TOW_LOGIN_CHECK,"f");
// if Tow service provider already login
                if(!cre_login.equals("f"))
                {
// creating Intent object and start MapsActivity by passing Intent
                    Intent intent =new Intent(getApplicationContext(),MapsActivity.class);
                    intent.putExtra(IntentAttrHelper.USER_TYPE_KEY,"Tow");
                    intent.putExtra(IntentAttrHelper.USER_NAME_KEY,sh.
                            getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_TOW_KEY,"no_tow_name"));
                    startActivity(intent);

                }
// if Tow service provider not already login
                else if(cre_login.equals("f")) {
// creating Intent object and start Login_Page by passing Intent
                    Intent intent = new Intent(getApplicationContext(), Login_Page.class);
                    intent.putExtra(IntentAttrHelper.USER_TYPE_KEY, "Tow");
                    startActivity(intent);
                }
            }
        });

//Tow_layout click listener
        linearLayout_tow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

//check value exit in share preferences or not
                sh=getSharedPreferences("MyApp",MODE_PRIVATE);
                String cre_login=sh.getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_TOW_LOGIN_CHECK,"f");
// if Tow service provider already login
                if(!cre_login.equals("f"))
                {
// creating Intent object and start Login_Page by passing Intent
                    Intent intent =new Intent(getApplicationContext(),MapsActivity.class);
                    intent.putExtra(IntentAttrHelper.USER_TYPE_KEY,"Tow");
                    intent.putExtra(IntentAttrHelper.USER_NAME_KEY,sh.
                            getString(SharePreferenceAttrHelper.SHARE_PREFERENCE_USER_NAME_TOW_KEY,"no_tow_name"));
                    startActivity(intent);
                }
// if Tow service provider not already login
                else if(cre_login.equals("f")) {
                    Intent intent = new Intent(getApplicationContext(), Login_Page.class);
                    intent.putExtra(IntentAttrHelper.USER_TYPE_KEY, "Tow");
                    startActivity(intent);
                }
            }
        });
    }



}