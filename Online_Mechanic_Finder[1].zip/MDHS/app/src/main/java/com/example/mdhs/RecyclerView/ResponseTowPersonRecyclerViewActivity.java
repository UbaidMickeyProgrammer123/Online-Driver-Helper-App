package com.example.mdhs.RecyclerView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.example.mdhs.CustomAdapters.MyAdapterMechanicResponce;
import com.example.mdhs.CustomAdapters.MyAdapterTowPeronResponce;
import com.example.mdhs.DataClasses.ServiceRequest;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ResponseTowPersonRecyclerViewActivity extends AppCompatActivity {
    //    MechanicResponseRecylerView class for display all towPerson response for particular driver
//    declaration var
    private List<ServiceRequest> serviceRequestList;
    RecyclerView recyclerView_response_tow_person;
    String userType,userName;
    MyAdapterTowPeronResponce myAdapterTowPeronResponce;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_response_tow_person_recycler_view);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
//        declare and initialize userType String to store intent USER_TYPE_KEY value

//        declare and initialize userType String to store intent USER_TYPE_KEY value
        userType = bundle.getString(IntentAttrHelper.USER_TYPE_KEY, "NILL");
        userName = bundle.getString(IntentAttrHelper.USER_NAME_KEY, "NILL");

//bind recycler view
        recyclerView_response_tow_person =findViewById(R.id.TowPersonResponceRecyView_layout_id);
        recyclerView_response_tow_person.setHasFixedSize(true);
        recyclerView_response_tow_person.setLayoutManager(new LinearLayoutManager(this));
        serviceRequestList=new ArrayList<>();
        //get all towPerson response
        getTowPersonResponse();
    }
    //get all towPerson response of particular driver by its name

    private void getTowPersonResponse() {
        final DatabaseReference nm= FirebaseDatabase.getInstance().getReference().child("DB").
                //parent is driver child are tow person
                child("ResponseFromTowPerson").child(userName);
        nm.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    for (DataSnapshot npsnapshot : dataSnapshot.getChildren()){
                        ServiceRequest l=npsnapshot.getValue(ServiceRequest.class);
                        serviceRequestList.add(l)   ;
                    }
                    myAdapterTowPeronResponce=new MyAdapterTowPeronResponce(serviceRequestList,getApplicationContext());
                    recyclerView_response_tow_person.setAdapter(myAdapterTowPeronResponce);
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
}