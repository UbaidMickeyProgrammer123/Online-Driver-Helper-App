package com.example.mdhs.Account;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.mdhs.DataClasses.Driver;
import com.example.mdhs.DataClasses.Mechanic;
import com.example.mdhs.DataClasses.TowPerson;
import com.example.mdhs.FireBaseDB.FireBaseDAO;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.HelperClass.SharePreferenceAttrHelper;
import com.example.mdhs.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SignUpActivity extends AppCompatActivity {
//declare similarUserExit check when user sign up
private boolean similarUserExit;

    //    declare user type string for get intent
    private String userType = "";

    //declare  on share preference object
    private SharedPreferences sharedPreferences;
    // declare firebase database

    DatabaseReference databaseReference;

    //declaring variables buttons
    Button button_back1, button_signup1;
    //declaring variables image
//    ImageButton img_location;
    //declaring variables check box
    CheckBox checkBox_wash, checkBox_repair, checkBox_tyre;
    //declaring variables name
    TextView textView_name;
    //declaring address for sign in textview
//    TextView textView_address;

//    declare edit text
    EditText editText_name,editText_contactNo, editText_UserName,editText_pass,editText_rePass;

//declare progress bar;
    ProgressBar progressBar;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup_activity);
//get database instance

//initialization of variatxt_name_id);
//        editText_contactNo=findViewById(R.bles

        button_back1 = findViewById(R.id.button_back1);
        button_signup1 = findViewById(R.id.button_signup1);
//        img_location = findViewById(R.id.image_location_id);
        checkBox_wash = findViewById(R.id.checkBox_wash_id);
        checkBox_repair = findViewById(R.id.checkBox_repair_id);
        checkBox_tyre = findViewById(R.id.checkBox_tyre_id);

//        initialize edittext
        editText_name=findViewById(R.id.txt_name_id);
        editText_contactNo=findViewById(R.id.txt_contact_id);
        editText_UserName =findViewById(R.id.txt_userName_id);
        editText_pass=findViewById(R.id.txt_password_id);
        editText_rePass=findViewById(R.id.txt_cpassword_id);

        //initialize progress bar
        progressBar=findViewById(R.id.progressBar_signUp_id);
//get intent data from main start screen
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
//        declare and initialize userType String to store intent USER_TYPE_KEY value
        userType = bundle.getString(IntentAttrHelper.USER_TYPE_KEY, "NILL");

//check if user is not mechanic then hide all check boxes

        if (!(userType.equals("Mechanic"))) {
            checkBox_wash.setVisibility(View.GONE);
            checkBox_repair.setVisibility(View.GONE);
            checkBox_tyre.setVisibility(View.GONE);

        }
/*
Detail:
the register page in which any type of user register himself in system
the one pre condition for registration user name cannot already exit in system
other wise system display error message for already exit user message
 */

//click listener in sign up button
        button_signup1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //set progress bar visible when click on signUp button
                progressBar.setVisibility(View.VISIBLE);
                saveRegisterData();
                //set progress bar invisible when after saveRegisterData  method is complete
                progressBar.setVisibility(View.INVISIBLE);


            }
        });
        //back click listener
        button_back1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(getApplicationContext(), Login_Page.class);
intent1.putExtra(IntentAttrHelper.USER_TYPE_KEY,userType);
                startActivity(intent1);
            }
        });




    }
    //method for saveRegisterData
    public void saveRegisterData(){


        String name=editText_name.getText().toString();
        String contactNo=editText_contactNo.getText().toString();
        String userName= editText_UserName.getText().toString();
        String pass=editText_pass.getText().toString();
        String rePass=editText_rePass.getText().toString();
        Boolean repairService=checkBox_repair.isChecked();
        Boolean washService=checkBox_wash.isChecked();
        Boolean tyreService=checkBox_tyre.isChecked();
        //check condition for check box



        //check condition if empty then show error message
        if(name.equals("")){
            editText_name.setError("Please enter value here");
        }
        else if(contactNo.equals("")){
            editText_contactNo.setError("Please enter value here");

        }
        else if(userName.equals("")){
            editText_UserName.setError("Please enter value here");

        }
        else if(pass.equals("")){
            editText_pass.setError("Please enter value here");

        }
        else if(rePass.equals("")){
            editText_rePass.setError("Please enter value here");

        }
        else if(!rePass.equals(pass)){
            editText_rePass.setError("Please check your confirm password");

        }
else {

    //check user already existence
            checkSameUserExistance(userName, name, contactNo, pass, rePass,"Nill",
                    0.00000,0.0000,
                    washService,repairService,tyreService,0,false);
        }


    }
    //if username already exit then suggest this user already please try another user name
    public  void checkSameUserExistance(String userName, String name, String contactNo,
                                        String pass, String rePass, String address, double lat,
                                        double lon, Boolean washService, Boolean repairService,
                                        Boolean tyreService, double tJob, boolean isActive) {
        similarUserExit = false;
//if user is mechanic
        if (userType.equals("Mechanic")) {

        final DatabaseReference nm = FirebaseDatabase.getInstance().getReference().child("DB").
                child("Mechanic");
        nm.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot npsnapshot : dataSnapshot.getChildren()) {
                        Mechanic l = npsnapshot.getValue(Mechanic.class);

                        if (userName.equals(l.getUserName())) {

                            similarUserExit = true;
//                            Toast.makeText(getApplicationContext(), "same user exit " + similarUserExit, Toast.LENGTH_SHORT).show();


                        }

                    }
//                    if  user cannot exit in db ten register his account other wise show user userName already exit
                    if (!similarUserExit) {


//                        Toast.makeText(getApplicationContext(), "there is no user exit", Toast.LENGTH_SHORT).show();
                        //getting the reference of db node

                        FireBaseDAO fireBaseDAO = new FireBaseDAO();
                        //create mechanic object
                        //also set default latitude , logitude value
                        Mechanic ObjMec = new Mechanic(userName, name, contactNo, pass, rePass, 0.000,0.0000,"",
                                washService, repairService, tyreService, 0, false);
                        //set Mechanic data on fb
                        fireBaseDAO.setUserRegisterData(ObjMec, userName, userType, getApplicationContext());

                        Intent intent = new Intent(getApplicationContext(), Login_Page.class);
                        intent.putExtra(IntentAttrHelper.USER_TYPE_KEY, userType);
                        startActivity(intent);
                        finish();


                    }
                    else{
                        editText_UserName.setError("UserName already exit");
                    }


                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }
        //if user is Driver

        else if (userType.equals("Driver")) {

            final DatabaseReference nm = FirebaseDatabase.getInstance().getReference().child("DB").
                    child("Driver");
            nm.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        for (DataSnapshot npsnapshot : dataSnapshot.getChildren()) {
                            Driver l = npsnapshot.getValue(Driver.class);

                            if (userName.equals(l.getUserName())) {

                                similarUserExit = true;
//                                Toast.makeText(getApplicationContext(), "same user exit " + similarUserExit, Toast.LENGTH_SHORT).show();


                            }

                        }
                        if (!similarUserExit) {


//                            Toast.makeText(getApplicationContext(), "there is no user exit", Toast.LENGTH_SHORT).show();
                            //getting the reference of db node

                            FireBaseDAO fireBaseDAO=new FireBaseDAO();
                            //create driver object

                            Driver ObjDri = new Driver(userName, name, contactNo, pass, rePass,
                                    "Nill",0.00000,0.0000);
                            //set Driver data on fb
                            fireBaseDAO.setUserRegisterData(ObjDri,userName,userType,getApplicationContext());
                            Intent intent=new Intent(getApplicationContext(),Login_Page.class);
                            intent.putExtra(IntentAttrHelper.USER_TYPE_KEY,userType);
                            startActivity(intent);
                            finish();


                        }
                        else{
                            editText_UserName.setError("UserName already exit");
                        }


                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });

        }
        //if user is Tow

        else if (userType.equals("Tow")) {

            final DatabaseReference nm = FirebaseDatabase.getInstance().getReference().child("DB").
                    child("Tow");
            nm.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        for (DataSnapshot npsnapshot : dataSnapshot.getChildren()) {
                            TowPerson l = npsnapshot.getValue(TowPerson.class);

                            if (userName.equals(l.getUserName())) {

                                similarUserExit = true;
//                                Toast.makeText(getApplicationContext(), "same user exit " + similarUserExit, Toast.LENGTH_SHORT).show();


                            }

                        }
                        if (!similarUserExit) {


//                            Toast.makeText(getApplicationContext(), "there is no user exit", Toast.LENGTH_SHORT).show();
                            //getting the reference of db node

                            FireBaseDAO fireBaseDAO=new FireBaseDAO();
                            //create driver object

                            TowPerson towPerson = new TowPerson(userName, name, contactNo, pass, rePass,
                                    "Nill",0.00000,0.0000);
                            //set Driver data on fb
                            fireBaseDAO.setUserRegisterData(towPerson,userName,userType,getApplicationContext());
                            Intent intent=new Intent(getApplicationContext(),Login_Page.class);
                            intent.putExtra(IntentAttrHelper.USER_TYPE_KEY,userType);
                            startActivity(intent);
                            finish();


                        }
                        else{
                            editText_UserName.setError("UserName already exit");
                        }


                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });

        }
    }

}







