package com.example.mdhs.DataClasses;

public class Person {
    String UserName,name,contact,pass,rePass;
    Double latitude,longitude;
    String address;
    public Person(String UserName, String name, String contact, String pass, String rePass,
                  String address, Double latitude, Double longitude) {
        this.UserName = UserName;
        this.name = name;
        this.contact = contact;
        this.pass = pass;
        this.rePass = rePass;
        this.latitude=latitude;
        this.longitude=longitude;
        this.address=address;
    }
    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }





    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        this.UserName = userName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getRePass() {
        return rePass;
    }

    public void setRePass(String rePass) {
        this.rePass = rePass;
    }


}
