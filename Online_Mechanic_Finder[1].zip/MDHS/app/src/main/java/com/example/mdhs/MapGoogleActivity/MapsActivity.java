package com.example.mdhs.MapGoogleActivity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mdhs.FireBaseDB.FireBaseDAO;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.HelperClass.SharePreferenceAttrHelper;
import com.example.mdhs.MainActivity;
import com.example.mdhs.Personal_Profile_Activity;
import com.example.mdhs.R;
import com.example.mdhs.RecyclerView.FeebackTowPersonRecyclerView;
import com.example.mdhs.RecyclerView.FeedbackMechanicRecyclerView;
import com.example.mdhs.RecyclerView.RecyclerViewFindMechanic;
import com.example.mdhs.RecyclerView.MechanicResponseRecylerView;
import com.example.mdhs.RecyclerView.RecyclerViewFindTowPerson;
import com.example.mdhs.RecyclerView.ResponseTowPersonRecyclerViewActivity;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.mdhs.databinding.ActivityMapsBinding;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.PermissionDeniedResponse;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.single.PermissionListener;

import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks ,
        GoogleApiClient.OnConnectionFailedListener,
        com.google.android.gms.location.LocationListener{

    //declare  on share preference object
    private SharedPreferences sharedPreferences;
    //initialize  and declare key for store image location address for intent
//    declare map prodress bar
    ProgressBar progressBarMap;
    //declare fragment
    View fragment_map;
//declare Button
    Button button_back, button_find_mechanic,button_response_mechanic,button_request_driver
        ,button_job_status,button_logout,button_find_towPerson,button_response_towPerson,button_view_profile;
TextView textView_note;
//declare switch
    Switch aSwitch_map;
    LinearLayout linearLayout_map;
//declare object for import classes
    FusedLocationProviderClient fusedLocationProviderClient;
    private double latitude,longitude;
    private String address;
    private GoogleMap mMap;
    Geocoder geocoder;
    private GoogleApiClient mGoogleApiClient;
    private Location mlocation;
    private LocationManager mLocationManager;
    private LocationRequest mLocationRequest;
    private com.google.android.gms.location.LocationListener listner;
    private long UPDATE_INTERVAL=2000;
    private long FASTEST_INTERVAL=5000;
    private LocationManager locationManager;
    private LatLng latlng;
    private boolean isPermission=false;
    private ActivityMapsBinding binding;
    //We want to add marker once, so we count map_marker
    private int count_map_marker=0;

    //    declare user type string for get intent
    private  String userType = "";
     private String userName = "";

    //declare textView Header email
    TextView textView_user_detail_header,textView_show_msg_for_show_map;

//    declare SupportMapFragment mapFragment
//SupportMapFragment mapFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

//get intent data from main start screen
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
//        declare and initialize userType String to store intent USER_TYPE_KEY value
         userType = bundle.getString(IntentAttrHelper.USER_TYPE_KEY, "Nill From Login");
         userName = bundle.getString(IntentAttrHelper.USER_NAME_KEY, "Nill From Login");


        //initialize  and set textView
        textView_user_detail_header =findViewById(R.id.textView_near_find_mechanic_Header_id);
        textView_user_detail_header.setText("Loading Please Wait .....");
        textView_note=findViewById(R.id.textView14_note_id);

        // initialize  buttons
        button_back=findViewById(R.id.back_button_map_id);
        button_find_mechanic =findViewById(R.id.button_hire_mechanic_id);
        button_response_mechanic=findViewById(R.id.button_mechanic_responce_id);
        button_request_driver=findViewById(R.id.button_driver_request_id);
        button_job_status=findViewById(R.id.button_job_status_id);
        button_logout=findViewById(R.id.button_logout_id);
button_find_towPerson=findViewById(R.id.button_find_towPerson_id);
button_response_towPerson=findViewById(R.id.button_response_towPerson_id);
button_view_profile=findViewById(R.id.button_view_profile_id);
aSwitch_map=findViewById(R.id.switch1_map_id);
linearLayout_map=findViewById(R.id.linearLayout_map_id);

//bind fragment map
        fragment_map=findViewById(R.id.map);
//set on change click listener
        aSwitch_map.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
linearLayout_map.setVisibility(View.INVISIBLE);
                    aSwitch_map.setText("Switch View Map");
                }
                else if(!isChecked){
                    linearLayout_map.setVisibility(View.VISIBLE);
                    aSwitch_map.setText("Switch Hide Map");
                }
            }
        });

        //check user type if driver then hide irrelivent buttons
        if(userType.equals("Mechanic")||userType.equals("Tow")){
            button_find_mechanic.setVisibility(View.GONE);
            button_response_mechanic.setVisibility(View.GONE);
            button_find_towPerson.setVisibility(View.GONE);
            button_response_towPerson.setVisibility(View.GONE);

            button_job_status.setVisibility(View.VISIBLE);
            button_request_driver.setVisibility(View.VISIBLE);
        }
        else if(userType.equals("Driver")){
            button_job_status.setVisibility(View.GONE);
            button_request_driver.setVisibility(View.GONE);

            button_find_mechanic.setVisibility(View.VISIBLE);
            button_response_mechanic.setVisibility(View.VISIBLE);
            button_find_towPerson.setVisibility(View.VISIBLE);
            button_response_towPerson.setVisibility(View.VISIBLE);
        }


        //when user click on logout button then change permission access
        button_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // if user is mechanic then change SHARE_PREFERENCE_MECHANIC_LOGIN_CHECK and assign f value
                if(userType.equals("Mechanic")){

                    sharedPreferences =getSharedPreferences("MyApp",MODE_PRIVATE);
                    SharedPreferences.Editor editor=sharedPreferences.edit();
                    editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_MECHANIC_LOGIN_CHECK,"f");
                    editor.commit();
                    Intent intent1=new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent1);
                    finish();
                }
                // if user is Driver then change SHARE_PREFERENCE_DRIVER_LOGIN_CHECK and assign f value

                else if(userType.equals("Driver")){
                    sharedPreferences =getSharedPreferences("MyApp",MODE_PRIVATE);
                    SharedPreferences.Editor editor=sharedPreferences.edit();
                    editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_DRIVER_LOGIN_CHECK,"f");
                    editor.commit();
                    Intent intent1=new Intent(getApplicationContext(),MainActivity.class);
                    startActivity(intent1);
                    finish();
                }
                // if user is Tow then change SHARE_PREFERENCE_TOW_LOGIN_CHECK and assign f value

                else if(userType.equals("Tow")){
                    sharedPreferences =getSharedPreferences("MyApp",MODE_PRIVATE);
                    SharedPreferences.Editor editor=sharedPreferences.edit();
                    editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_TOW_LOGIN_CHECK,"f");
                    editor.commit();
                    Intent intent1=new Intent(getApplicationContext(),MainActivity.class);
                    startActivity(intent1);
                    finish();
                }
                // if user is Admin then change SHARE_PREFERENCE_ADMIN_LOGIN_CHECK and assign f value

                else if(userType.equals("Admin")){
                    sharedPreferences =getSharedPreferences("MyApp",MODE_PRIVATE);
                    SharedPreferences.Editor editor=sharedPreferences.edit();
                    editor.putString(SharePreferenceAttrHelper.SHARE_PREFERENCE_ADMIN_LOGIN_CHECK,"f");
                    editor.commit();
                    Intent intent1=new Intent(getApplicationContext(),MainActivity.class);
                    startActivity(intent1);
                    finish();
                }
            }
        });

//        initialize progress bar
        progressBarMap=findViewById(R.id.progressBar_map_id);
        //set visibily progress bar when create map activity for loading
        progressBarMap.setVisibility(View.VISIBLE);
        //click listener on buttons
//  click on back button
        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent intent1=new Intent(getApplicationContext(),MainActivity.class);
                    startActivity(intent1);
                    finish();
                }catch (Exception exception){
                    Toast.makeText(getApplicationContext(), "ReOpen Loading Page ", Toast.LENGTH_SHORT).show();
                }

            }
        });
        //when driver click on find tow person button
        button_find_towPerson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(getApplicationContext(), RecyclerViewFindTowPerson.class);
                intent1.putExtra(IntentAttrHelper.LATITUDE_INTENT_KEY,latitude);
                intent1.putExtra(IntentAttrHelper.LONGITUDE_INTENT_KEY,longitude);
                intent1.putExtra(IntentAttrHelper.USER_TYPE_KEY,userType);
                intent1.putExtra(IntentAttrHelper.USER_NAME_KEY, userName);
                startActivity(intent1);
            }
        });
//check find mechanic button press
        button_find_mechanic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent1=new Intent(getApplicationContext(), RecyclerViewFindMechanic.class);
                intent1.putExtra(IntentAttrHelper.LATITUDE_INTENT_KEY,latitude);
                intent1.putExtra(IntentAttrHelper.LONGITUDE_INTENT_KEY,longitude);
                intent1.putExtra(IntentAttrHelper.USER_TYPE_KEY,userType);
                intent1.putExtra(IntentAttrHelper.USER_NAME_KEY, userName);
                startActivity(intent1);
//                Toast.makeText(getApplicationContext(), latitude+" "+longitude, Toast.LENGTH_SHORT).show();
            }
        });

        //check request button press
        button_request_driver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(userType.equals("Mechanic")){
                    Intent intent1=new Intent(getApplicationContext(), RecyclerViewFindMechanic.class);
                    intent1.putExtra(IntentAttrHelper.LATITUDE_INTENT_KEY,latitude);
                    intent1.putExtra(IntentAttrHelper.LONGITUDE_INTENT_KEY,longitude);
                    intent1.putExtra(IntentAttrHelper.USER_TYPE_KEY,userType);
                    intent1.putExtra(IntentAttrHelper.USER_NAME_KEY, userName);
                    startActivity(intent1);
                }
                else if(userType.equals("Tow")){
                    Intent intent1=new Intent(getApplicationContext(),RecyclerViewFindTowPerson.class);
                    intent1.putExtra(IntentAttrHelper.LATITUDE_INTENT_KEY,latitude);
                    intent1.putExtra(IntentAttrHelper.LONGITUDE_INTENT_KEY,longitude);
                    intent1.putExtra(IntentAttrHelper.USER_TYPE_KEY,userType);
                    intent1.putExtra(IntentAttrHelper.USER_NAME_KEY, userName);
                    startActivity(intent1);
                }
//                Toast.makeText(getApplicationContext(), "click button_request_driver", Toast.LENGTH_SHORT).show();

            }
        });
//when driver click on tow person resonse
        button_response_towPerson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(getApplicationContext(), ResponseTowPersonRecyclerViewActivity.class);
                intent1.putExtra(IntentAttrHelper.USER_TYPE_KEY,userType);
                intent1.putExtra(IntentAttrHelper.USER_NAME_KEY, userName);
                startActivity(intent1);
            }
        });
//        when user click on reponse mechanic

        button_response_mechanic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(getApplicationContext(), MechanicResponseRecylerView.class);

                intent1.putExtra(IntentAttrHelper.USER_TYPE_KEY,userType);
                intent1.putExtra(IntentAttrHelper.USER_NAME_KEY, userName);
                startActivity(intent1);

            }
        });

        //when mechanic user click on job status
        button_job_status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                send activity to FeedbackMechanicRecyclerView
                if(userType.equals("Mechanic")){
                    Intent intent1=new Intent(getApplicationContext(), FeedbackMechanicRecyclerView.class);
                    intent1.putExtra(IntentAttrHelper.USER_NAME_KEY,userName);
                    startActivity(intent1);
                    finish();
                }
               else if(userType.equals("Tow")){
                    Intent intent1=new Intent(getApplicationContext(), FeebackTowPersonRecyclerView.class);
                    intent1.putExtra(IntentAttrHelper.USER_NAME_KEY,userName);
                    startActivity(intent1);
                    finish();
                }

            }
        });
//when user click on view profile button
        button_view_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(getApplicationContext(), Personal_Profile_Activity.class);
                intent1.putExtra(IntentAttrHelper.USER_TYPE_KEY,userType);
                intent1.putExtra(IntentAttrHelper.USER_NAME_KEY,userName);
                startActivity(intent1);
            }
        });

//check permission
        if(requestSinglePermission())
        {
            if(isPermission){
                //location access properly then hide this note
                textView_note.setVisibility(View.GONE);
            }
            // Obtain the SupportMapFragment and get notified when the map is ready to be used.
            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.map);
            mapFragment.getMapAsync(this);

            mGoogleApiClient=new GoogleApiClient.Builder(getApplicationContext())
                    .addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this)
                    .addApi(LocationServices.API)
                    .build();

            mLocationManager=(LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
//            Toast.makeText(getApplicationContext(), "checkLocation", Toast.LENGTH_SHORT).show();
            checkLocation();

        }

    }


    private boolean checkLocation() {
        if(!isLocationEnabled(getApplicationContext())){
            showAlert();
        }
        return isLocationEnabled(getApplicationContext());
    }
//show alert when user cannot on location
    private void showAlert() {
        final AlertDialog.Builder dialog=new AlertDialog.Builder(this);
        dialog.setTitle("Enable Location")
                .setMessage("Your Location Setting is set to 'Off'. \nPlease Enable Location to "+
                        "use this app")
                .setPositiveButton("Location Settings", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent myintent=new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(myintent);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
        dialog.show();

    }


    public static boolean isLocationEnabled(Context context) {
        return getLocationMode(context) != Settings.Secure.LOCATION_MODE_OFF;
    }
    private static int getLocationMode(Context context) {
        return Settings.Secure.getInt(context.getContentResolver(), Settings.Secure.LOCATION_MODE, Settings.Secure.LOCATION_MODE_OFF);
    }

    private boolean requestSinglePermission() {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            Dexter.withActivity(this)
                    .withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                    .withListener(new PermissionListener() {
                        @Override
                        public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                            isPermission = true;

                        }

                        @Override
                        public void onPermissionDenied(PermissionDeniedResponse permissionDeniedResponse) {
                            if (permissionDeniedResponse.isPermanentlyDenied()) {
                                isPermission = false;
                            }

                        }

                        @Override
                        public void onPermissionRationaleShouldBeShown(PermissionRequest permissionRequest, PermissionToken permissionToken) {
permissionToken.continuePermissionRequest();
                        }
                    }).check();

//        }
        return isPermission;
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)
        != PackageManager.PERMISSION_GRANTED &&
        ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)
        !=PackageManager.PERMISSION_GRANTED){
            return;
        }
        startLocationUpdates();
        mlocation=LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);

        if(mlocation!=null)
        {
            startLocationUpdates();
        }
        else{
//            Toast.makeText(this,"Location not Detected",Toast.LENGTH_SHORT).show();
        }

    }
//when location updates
    private void startLocationUpdates() {
//        Toast.makeText(getApplicationContext(), "In Start location Update", Toast.LENGTH_SHORT).show();
        mLocationRequest= com.google.android.gms.location.LocationRequest.create()
                .setPriority(com.google.android.gms.location.LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(UPDATE_INTERVAL)
                .setFastestInterval(FASTEST_INTERVAL);

        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)
        !=PackageManager.PERMISSION_GRANTED &&
        ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)!=
        PackageManager.PERMISSION_GRANTED){
            return ;
        }

        LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient,mLocationRequest,this);
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
//When the device's location is moved then this method is called
    @Override
    public void onLocationChanged(@NonNull Location location) {
//        Toast.makeText(getApplicationContext(), "onLocationChanged", Toast.LENGTH_SHORT).show();
        latitude = location.getLatitude();
        longitude = location.getLongitude();
        String msg="Updated Location: "+
                Double.toString(location.getLatitude())+","+
                Double.toString(location.getLongitude());
        //update header text view with location
        textView_user_detail_header.setText("USER: "+ userName +"\n"+userType+"\n"+
               getCompleteAddressString(location.getLatitude(),location.getLongitude()));
        address= getCompleteAddressString(location.getLatitude(),location.getLongitude());

        ///update record on firebase user current location
        FireBaseDAO fireBaseDAO =new FireBaseDAO();
        fireBaseDAO.updatedCurrentUserLocation(userName,latitude,longitude,address,userType,getApplicationContext());
        //invisible progress bar when data is updated on FireBase DB
        progressBarMap.setVisibility(View.GONE);
        //count for only one marker show

//        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
       if(count_map_marker==0)
       {
           latlng=new LatLng(location.getLatitude(),location.getLongitude());
           mMap.addMarker(new MarkerOptions().position(latlng).title(address));
           mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latlng,14F));
                   count_map_marker++;
       }





        Log.e("latitude", "latitude--" + latitude);






    }

    @Override
    protected void onStart() {
        super.onStart();
        if(mGoogleApiClient!=null)
        {
            mGoogleApiClient.connect();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        try {
            if(mGoogleApiClient.isConnected())
            {

                mGoogleApiClient.disconnect();
            }
        }catch (Exception exception){
            Toast.makeText(getApplicationContext(), "ReOpen Loading Page", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        try {
            Intent intent=new Intent(getApplicationContext(),MainActivity.class);
            startActivity(intent);
            finish();
        }catch (Exception e){
        }

    }
//get address from geocoder
    @SuppressLint("LongLogTag")
    private String getCompleteAddressString(double LATITUDE, double LONGITUDE) {
        String strAdd = "";
        Geocoder geocoder = new Geocoder(this);
        try {
            List<Address> addresses = geocoder.getFromLocation(LATITUDE, LONGITUDE, 1);
            if (addresses != null) {
                Address returnedAddress = addresses.get(0);
                StringBuilder strReturnedAddress = new StringBuilder("");

                for (int i = 0; i <= returnedAddress.getMaxAddressLineIndex(); i++) {
                    strReturnedAddress.append(returnedAddress.getAddressLine(i)).append("\n");
                }
                strAdd = strReturnedAddress.toString();
                Log.w("My Current loction address", strReturnedAddress.toString());
            } else {
                Log.w("My Current loction address", "No Address returned!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.w("My Current loction address", "Canont get Address!");
        }
        return strAdd;
    }
}












