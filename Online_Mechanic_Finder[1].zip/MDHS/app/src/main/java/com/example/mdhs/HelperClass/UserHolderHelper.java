package com.example.mdhs.HelperClass;

import com.example.mdhs.DataClasses.Person;

import java.util.Comparator;

public class UserHolderHelper extends Person  {

    //create class for temp holder user while retrieve user data from firebase database
    Boolean isActive;
    String tJob;
    Double distance;
    Boolean washService;
    Boolean repairService;
    Boolean tyreService;
    public UserHolderHelper(String UserName, String name, String contact, String pass, String rePass, String address, Double latitude, Double longitude, Boolean isActive,
                            String tJob, Double distance, Boolean washService, Boolean repairService, Boolean tyreService) {
        super(UserName, name, contact, pass, rePass, address, latitude, longitude);
        this.isActive = isActive;
        this.tJob = tJob;
        this.distance = distance;
        this.washService = washService;
        this.repairService = repairService;
        this.tyreService = tyreService;
    }
    public Boolean getWashService() {
        return washService;
    }

    public void setWashService(Boolean washService) {
        this.washService = washService;
    }

    public Boolean getRepairService() {
        return repairService;
    }

    public void setRepairService(Boolean repairService) {
        this.repairService = repairService;
    }

    public Boolean getTyreService() {
        return tyreService;
    }

    public void setTyreService(Boolean tyreService) {
        this.tyreService = tyreService;
    }






    public UserHolderHelper(String userName, String name, String contact, String pass, String rePass,
                            String address, Double latitude, Double longitude, double distance, int totalJobs, Boolean isActive) {
        super(userName, name, contact, pass, rePass, address, latitude, longitude);
        this.distance = distance;
        this.tJob = String.valueOf(totalJobs);
        this.isActive = isActive;
    }

    public Boolean getActive() {
        return isActive;
    }

    public void setActive(Boolean active) {
        isActive = active;
    }

    public String gettJob() {
        return tJob;
    }

    public void settJob(String tJob) {
        this.tJob = tJob;
    }


    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

//take distance attribute for shorting array

    /*Comparator for sorting the list by roll no*/
    public static Comparator<UserHolderHelper> userDistan = new Comparator<UserHolderHelper>() {

        @Override
        public int compare(UserHolderHelper o1, UserHolderHelper o2) {

            int delta = (int)(o1.getDistance() - o2.getDistance());

//            if(delta <= 0.00001) return 0;
//            if(delta <= 0.1) return 1;
////            return int
            return delta;
        }


    };
}
