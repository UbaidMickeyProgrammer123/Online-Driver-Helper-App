package com.example.mdhs.RecyclerView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.example.mdhs.CustomAdapters.MyAdapterRequestCheckByMechanic;
import com.example.mdhs.CustomAdapters.MyAdapterView;
import com.example.mdhs.DataClasses.Mechanic;
import com.example.mdhs.DataClasses.ServiceRequest;
import com.example.mdhs.HelperClass.DistanceHelper;
import com.example.mdhs.HelperClass.IntentAttrHelper;
import com.example.mdhs.HelperClass.UserHolderHelper;
import com.example.mdhs.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class RecyclerViewFindMechanic extends AppCompatActivity {
    //    Recycler view for view All nearest towPerson
//Declare  arraylist
    private List<Mechanic> listData;
    private List<ServiceRequest> serviceRequestList;
    private List<UserHolderHelper> userHolderHelperList;
//    declare DistanceHelper, RecyclerView, MyAdapterView,MyAdapterRequestCheckByMechanic objects
    private DistanceHelper distanceHelper;
    private RecyclerView rv;
    private MyAdapterView adapter;
    private MyAdapterRequestCheckByMechanic myAdapterRequestCheckByMechanic;
    private TextView textView_near_mechanic_or_request_mechanic_header;

    // initialize for intent_latidute, intent_logitude
    private Double intent_latidute = 0.00;
    private Double intent_logitude = 0.00;
    // declare and initialize key for latitude and logitude for intent
    // declare and initialize key for latitude and logitude for send intent to another activity

    //    declare user type string for get intent
    private String userType = "";
    private String userName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mechanic_recyler_veiw);
        //get intent data from main start screen
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
//        declare and initialize userType String to store intent USER_TYPE_KEY value
        intent_latidute = bundle.getDouble(IntentAttrHelper.LATITUDE_INTENT_KEY, 0.000);
        intent_logitude = bundle.getDouble(IntentAttrHelper.LONGITUDE_INTENT_KEY, 0.000);
//        declare and initialize userType String to store intent USER_TYPE_KEY value
        userType = bundle.getString(IntentAttrHelper.USER_TYPE_KEY, "NILL");
        userName = bundle.getString(IntentAttrHelper.USER_NAME_KEY, "NILL");

//bind xml view
        rv = (RecyclerView) findViewById(R.id.mechanicRecyView_layout_id);
        textView_near_mechanic_or_request_mechanic_header=findViewById
                (R.id.textView14_near_mechanic_and_request_driver_heading_id);

        rv.setHasFixedSize(true);
        rv.setLayoutManager(new LinearLayoutManager(this));
        //initialization array list for listData, userHolderHelperList, distanceHelper
        listData = new ArrayList<>();
        userHolderHelperList = new ArrayList<>();
        distanceHelper = new DistanceHelper();
        if (userType.equals("Driver")) {
            textView_near_mechanic_or_request_mechanic_header.setText("Nearest Mechanics List");
            getMechanicData();
        } else if (userType.equals("Mechanic")) {
            textView_near_mechanic_or_request_mechanic_header.setText("Nearest Driver Request List");
            getDriverRequest();
        }


    }
// if user is towPerson then recycler view use for display DriverRequest for towPerson
    private void getDriverRequest() {
        final DatabaseReference nm = FirebaseDatabase.getInstance().getReference().child("DB").
                child("RequestToMechanic").child(userName);
        nm.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot npsnapshot : dataSnapshot.getChildren()) {
                        ServiceRequest l = npsnapshot.getValue(ServiceRequest.class);

//    }
                        UserHolderHelper userHolderHelper1 = new UserHolderHelper(
                                l.getReqFromUserName(),
//                                pass request response in name parameter for temp hold
                                l.getReqToresponce(),
                                l.getReqFromContact(),
                                "",
                                "",
                                l.getReqFromAddress(),
                                Double.valueOf(l.getReqFromLatitude()),
                                Double.valueOf(l.getReqFromLogitude()),
                                distanceHelper.distance(intent_latidute, intent_logitude, Double.valueOf(l.getReqFromLatitude()),
                                        Double.valueOf(l.getReqFromLogitude()), "K")
                                , 0,
                                false

                        );
                        userHolderHelperList.add(userHolderHelper1);


                    }

                    myAdapterRequestCheckByMechanic = new MyAdapterRequestCheckByMechanic(userHolderHelperList);
                    rv.setAdapter(myAdapterRequestCheckByMechanic);


                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }
// if user is driver then recycler view use for display all near  mechanics for driver
    public void getMechanicData() {
        final DatabaseReference nm = FirebaseDatabase.getInstance().getReference().child("DB").child("Mechanic");
        nm.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (DataSnapshot npsnapshot : dataSnapshot.getChildren()) {
                        Mechanic l = npsnapshot.getValue(Mechanic.class);

// public UserHolderHelper(String UserName, String name, String contact, String pass,
// String rePass, String address, Double latitude, Double longitude, Boolean isActive,
//                            String tJob, Double distance, Boolean washService,
//                            Boolean repairService, Boolean tyreService) {
                        UserHolderHelper userHolderHelper1 = new UserHolderHelper(
                                l.getUserName(),
                                l.getName(),
                                l.getContact(),
                                l.getPass(),
                                l.getRePass(),
                                l.getAddress(),
                                l.getLatitude(),
                                l.getLongitude(),
                                 l.getActive()
                                ,String.valueOf(l.getTotalJobs())
                                ,distanceHelper.distance(intent_latidute, intent_logitude, l.getLatitude(),
                                l.getLongitude(), "K")
                                ,l.getWashService(),
                                l.getRepairService(),
                                l.getTyreService()

                        );
                        //filter only no active towPerson
                        if (l.getActive().equals(false)) {

                            userHolderHelperList.add(userHolderHelper1);
                        }


                    }
//apply distance base sorting decreasing wise in UserHolderHelper class
                    Collections.sort(userHolderHelperList, UserHolderHelper.userDistan);
                    //after sorting set data on recycler view
                    adapter = new MyAdapterView(userHolderHelperList);
                    rv.setAdapter(adapter);


                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }



}